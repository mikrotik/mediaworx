#
# TABLE STRUCTURE FOR: tblactivitylog
#

DROP TABLE IF EXISTS `tblactivitylog`;

CREATE TABLE `tblactivitylog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('1', 'Database Backup [database_backup_2018-02-25-12-28-51.zip]', '2018-02-25 12:28:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('2', 'Entity Delete [ID:4]', '2018-02-25 19:24:18', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('3', 'Intent Delete [ID:2]', '2018-02-25 20:59:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('4', 'Intent Delete [ID:3]', '2018-02-25 23:00:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('5', 'Intent Delete [ID:5]', '2018-02-26 02:29:28', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('6', 'Intent Delete [ID:4]', '2018-02-26 02:29:35', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('7', 'Entity Delete [ID:7]', '2018-02-26 02:29:40', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('8', 'Entity Delete [ID:5]', '2018-02-26 02:29:44', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('9', 'Entity Delete [ID:6]', '2018-02-26 02:29:47', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('10', 'Entity Delete [ID:8]', '2018-02-26 02:29:50', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('11', 'Entity Delete [ID:9]', '2018-02-26 02:29:53', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('12', 'Entity Delete [ID:10]', '2018-02-26 02:29:56', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('13', 'Entity Delete [ID:12]', '2018-02-26 02:29:59', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('14', 'Entity Delete [ID:11]', '2018-02-26 02:30:02', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('15', 'Intent Status Changed [IntentID: 1 Status(Active/Inactive): 0]', '2018-02-26 04:29:57', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('16', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 0]', '2018-02-26 04:30:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('17', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 1]', '2018-02-26 04:30:43', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('18', 'Intent Status Changed [IntentID: 1 Status(Active/Inactive): 1]', '2018-02-26 04:32:06', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('19', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 0]', '2018-02-26 04:35:34', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('20', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 1]', '2018-02-26 04:35:46', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('21', 'Intent Delete [ID:1]', '2018-02-26 13:04:07', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('22', 'Intent Delete [ID:2]', '2018-02-26 13:04:08', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('23', 'Intent Delete [ID:4]', '2018-02-26 13:27:07', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('24', 'Intent Delete [ID:3]', '2018-02-26 13:27:15', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('25', 'Intent Delete [ID:1]', '2018-02-26 13:29:07', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('26', 'Intent Delete [ID:2]', '2018-02-26 13:29:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('27', 'Entity Delete [ID:3]', '2018-02-26 13:29:35', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('28', 'Entity Delete [ID:1]', '2018-02-26 13:29:38', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('29', 'Entity Delete [ID:2]', '2018-02-26 13:29:41', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('30', 'Failed Login Attempt [Email:demo@demo.com, Is Staff Member:Yes, IP:127.0.0.1]', '2018-02-26 20:36:22', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('31', 'New Client Created [Echelon From Staff: 1]', '2018-02-26 21:49:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('32', 'Contact Created [Ahmet Gudenoglu]', '2018-02-26 21:49:57', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('33', 'New Agent Created [ID:4]', '2018-02-27 01:07:30', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('34', 'Agent Delete [ID:4]', '2018-02-27 01:30:39', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('35', 'New Agent Created [ID:5]', '2018-02-27 01:30:58', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('36', 'Agent Delete [ID:5]', '2018-02-27 12:08:58', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('37', 'New Agent Created [ID:6]', '2018-02-27 12:24:30', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('38', 'Agent Delete [ID:6]', '2018-02-27 12:25:47', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('39', 'New Agent Created [ID:7]', '2018-02-27 12:33:09', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('40', 'Agent Delete [ID:7]', '2018-02-27 12:34:02', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('41', 'New Agent Created [ID:8]', '2018-02-27 12:35:29', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('42', 'Agent Delete [ID:8]', '2018-02-27 12:36:15', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('43', 'New Agent Created [ID:9]', '2018-02-27 12:37:11', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('44', 'Agent Delete [ID:9]', '2018-02-27 12:38:05', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('45', 'New Agent Created [ID:10]', '2018-02-27 12:38:36', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('46', 'Agent Delete [ID:10]', '2018-02-27 13:03:06', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('47', 'New Agent Created [ID:11]', '2018-02-27 13:03:28', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('48', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 0]', '2018-02-27 13:24:23', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('49', 'Intent Status Changed [IntentID: 2 Status(Active/Inactive): 1]', '2018-02-27 13:24:34', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('50', 'Agent Delete [ID:11]', '2018-02-27 13:24:42', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('51', 'New Agent Created [ID:12]', '2018-02-27 13:25:00', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('52', 'Intent Delete [ID:14]', '2018-02-27 14:03:30', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('53', 'Intent Delete [ID:17]', '2018-02-27 18:26:01', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('54', 'Intent Delete [ID:22]', '2018-02-27 19:31:54', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('55', 'Intent Delete [ID:23]', '2018-02-27 20:06:41', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('56', 'Entity Delete [ID:1]', '2018-02-27 20:33:51', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('57', 'Entity Delete [ID:2]', '2018-02-27 20:43:18', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('58', 'Intent Delete [ID:25]', '2018-02-27 21:05:14', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('59', 'Intent Delete [ID:26]', '2018-02-27 22:14:47', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('60', 'Intent Delete [ID:27]', '2018-02-27 22:18:45', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('61', 'Database Backup [database_backup_2018-02-28-00-24-13.zip]', '2018-02-28 00:24:13', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('62', 'Intent Delete [ID:32]', '2018-02-28 08:37:56', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('63', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:34:11', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('64', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:36:12', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('65', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:40:39', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('66', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:41:31', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('67', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:42:00', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('68', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:43:05', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('69', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 0]', '2018-02-28 10:43:15', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('70', 'Intent Status Changed [IntentID: 34 Status(Active/Inactive): 1]', '2018-02-28 10:43:19', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('71', 'Agent Delete [ID:12]', '2018-02-28 11:20:46', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('72', 'New Agent Created [ID:13]', '2018-02-28 13:18:00', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('73', 'Intent Status Changed [IntentID: 37 Status(Active/Inactive): 1]', '2018-02-28 15:57:30', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('74', 'Intent Delete [ID:38]', '2018-02-28 16:48:52', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('75', 'Intent Delete [ID:39]', '2018-02-28 17:08:53', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('76', 'Intent Delete [ID:40]', '2018-02-28 17:08:58', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('77', 'Intent Delete [ID:41]', '2018-02-28 17:09:04', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('78', 'Intent Delete [ID:37]', '2018-02-28 17:25:37', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('79', 'Intent Delete [ID:34]', '2018-02-28 17:25:40', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('80', 'Intent Status Changed [IntentID: 42 Status(Active/Inactive): 1]', '2018-02-28 17:28:42', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('81', 'Intent Delete [ID:42]', '2018-02-28 17:29:38', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('82', 'Database Backup [database_backup_2018-02-28-18-43-04.zip]', '2018-02-28 18:43:04', ' ');
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('83', 'Entity Delete [ID:1]', '2018-02-28 22:31:57', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('84', 'Agent Delete [ID:13]', '2018-02-28 23:17:55', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('85', 'Failed Login Attempt [Email:ahmet.gudenoglu@gmail.com, Is Staff Member:No, IP:127.0.0.1]', '2018-03-01 07:50:52', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('86', 'Entity Delete [ID:2]', '2018-03-01 08:04:13', NULL);
INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES ('87', 'New Agent Created [ID:1]', '2018-03-01 08:48:29', NULL);


#
# TABLE STRUCTURE FOR: tblagents
#

DROP TABLE IF EXISTS `tblagents`;

CREATE TABLE `tblagents` (
  `agentid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `agent_name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `default_language` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `default_timezone` varchar(32) CHARACTER SET utf8 NOT NULL,
  `google_project` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `agent_image` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `client_access_token` varchar(64) CHARACTER SET utf8 NOT NULL,
  `developer_access_token` varchar(64) CHARACTER SET utf8 NOT NULL,
  `logging` tinyint(1) DEFAULT '0',
  `matchmode` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `threshold` decimal(9,2) DEFAULT NULL,
  `small_talk` int(1) DEFAULT '0',
  PRIMARY KEY (`agentid`,`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblagents` (`agentid`, `userid`, `agent_name`, `default_language`, `default_timezone`, `google_project`, `agent_image`, `description`, `client_access_token`, `developer_access_token`, `logging`, `matchmode`, `threshold`, `small_talk`) VALUES ('1', '1', 'Coffee-Shop', 'english', 'Europe/Belgrade', '', '8347592_orig.png', '', 'e55d612b-9ad9-5b5a-bf0c-4499887efe30', 'b8821477-79a3-5cf8-a966-c2872d0900f3', '0', 'hybird', '0.80', '1');


#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `message` text,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(100) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT '0',
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT '0',
  `longitude` varchar(300) DEFAULT NULL,
  `latitude` varchar(300) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT '0',
  `show_primary_contact` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `country` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`) VALUES ('1', 'Echelon', '', '', '0', '', '', '', '', '', '2018-02-26 21:49:00', '1', NULL, '', '', '', '', '0', '', '', '', '', '0', '', '', '', '0', '0');


#
# TABLE STRUCTURE FOR: tblcommentlikes
#

DROP TABLE IF EXISTS `tblcommentlikes`;

CREATE TABLE `tblcommentlikes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontactpermissions
#

DROP TABLE IF EXISTS `tblcontactpermissions`;

CREATE TABLE `tblcontactpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('1', '1', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('2', '2', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('3', '3', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('4', '4', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('5', '5', '1');
INSERT INTO `tblcontactpermissions` (`id`, `permission_id`, `userid`) VALUES ('6', '6', '1');


#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '1',
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_image` varchar(300) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `is_primary` (`is_primary`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`) VALUES ('1', '1', '1', 'Ahmet', 'Gudenoglu', 'demo@demo.com', '', '', '2018-02-26 21:49:57', '$2a$08$y4zrens/fhZdKpG9.6IhB.TiL6IuC8K7lVkTmKj3YO.ncgvVkBlhq', NULL, NULL, '127.0.0.1', '2018-03-01 08:48:08', NULL, '1', NULL, '');


#
# TABLE STRUCTURE FOR: tblcontractrenewals
#

DROP TABLE IF EXISTS `tblcontractrenewals`;

CREATE TABLE `tblcontractrenewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(11,2) DEFAULT NULL,
  `new_value` decimal(11,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT '0',
  `is_on_old_expiry_notified` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `description` text,
  `subject` varchar(300) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT '0',
  `contract_value` decimal(11,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT '0',
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracttypes
#

DROP TABLE IF EXISTS `tblcontracttypes`;

CREATE TABLE `tblcontracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int(5) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('1', 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('2', 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('3', 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('4', 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('5', 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('6', 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('7', 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('8', 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('9', 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('10', 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('11', 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('12', 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('13', 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('14', 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('15', 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('16', 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('17', 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('18', 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('19', 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('20', 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('21', 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('22', 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('23', 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('24', 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('25', 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('26', 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('27', 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('28', 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('29', 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('30', 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('31', 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('32', 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('33', 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('34', 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('35', 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('36', 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('37', 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('38', 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('39', 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('40', 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('41', 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('42', 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('43', 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('44', 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('45', 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('46', 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('47', 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('48', 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('49', 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('50', 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('51', 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('52', 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('53', 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('54', 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('55', 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('56', 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('57', 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('58', 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('59', 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('60', 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('61', 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('62', 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('63', 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('64', 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('65', 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('66', 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('67', 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('68', 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('69', 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('70', 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('71', 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('72', 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('73', 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('74', 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('75', 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('76', 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('77', 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('78', 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('79', 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('80', 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('81', 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('82', 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('83', 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('84', 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('85', 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('86', 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('87', 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('88', 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('89', 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('90', 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('91', 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('92', 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('93', 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('94', 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('95', 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('96', 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('97', 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('98', 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('99', 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('100', 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('101', 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('102', 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('103', 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('104', 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('105', 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('106', 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('107', 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('108', 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('109', 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('110', 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('111', 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('112', 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('113', 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('114', 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('115', 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('116', 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('117', 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('118', 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('119', 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('120', 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('121', 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('122', 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('123', 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('124', 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('125', 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('126', 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('127', 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('128', 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('129', 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('130', 'MK', 'Macedonia', 'The Former Yugoslav Republic of Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('131', 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('132', 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('133', 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('134', 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('135', 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('136', 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('137', 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('138', 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('139', 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('140', 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('141', 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('142', 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('143', 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('144', 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('145', 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('146', 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('147', 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('148', 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('149', 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('150', 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('151', 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('152', 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('153', 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('154', 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('155', 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('156', 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('157', 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('158', 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('159', 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('160', 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('161', 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('162', 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('163', 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('164', 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('165', 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('166', 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('167', 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('168', 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('169', 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('170', 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('171', 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('172', 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('173', 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('174', 'PH', 'Phillipines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('175', 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('176', 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('177', 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('178', 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('179', 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('180', 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('181', 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('182', 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('183', 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('184', 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('185', 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('186', 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('187', 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('188', 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('189', 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('190', 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('191', 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('192', 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('193', 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('194', 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('195', 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('196', 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('197', 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('198', 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('199', 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('200', 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('201', 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('202', 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('203', 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('204', 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('205', 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('206', 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('207', 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('208', 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('209', 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('210', 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('211', 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('212', 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('213', 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('214', 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('215', 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('216', 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('217', 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('218', 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('219', 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('220', 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('221', 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('222', 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('223', 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('224', 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('225', 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('226', 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('227', 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('228', 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('229', 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('230', 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('231', 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('232', 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('233', 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('234', 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('235', 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('236', 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('237', 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('238', 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('239', 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('240', 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('241', 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('242', 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('243', 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('244', 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('245', 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('246', 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('247', 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('248', 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('249', 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES ('250', 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `isdefault`) VALUES ('1', '$', 'USD', '1');
INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `isdefault`) VALUES ('2', '€', 'EUR', '0');


#
# TABLE STRUCTURE FOR: tblcustomeradmins
#

DROP TABLE IF EXISTS `tblcustomeradmins`;

CREATE TABLE `tblcustomeradmins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` text NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomerfiles_shares
#

DROP TABLE IF EXISTS `tblcustomerfiles_shares`;

CREATE TABLE `tblcustomerfiles_shares` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomergroups_in
#

DROP TABLE IF EXISTS `tblcustomergroups_in`;

CREATE TABLE `tblcustomergroups_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomersgroups
#

DROP TABLE IF EXISTS `tblcustomersgroups`;

CREATE TABLE `tblcustomersgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `options` mediumtext,
  `field_order` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '1',
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `only_admin` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_table` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_client_portal` int(11) NOT NULL DEFAULT '0',
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT '0',
  `bs_column` int(11) NOT NULL DEFAULT '12',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`fieldid`),
  KEY `fieldto` (`fieldto`),
  KEY `relid_2` (`relid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext,
  `encryption` varchar(3) DEFAULT NULL,
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `calendar_id` mediumtext,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`departmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldismissedannouncements
#

DROP TABLE IF EXISTS `tbldismissedannouncements`;

CREATE TABLE `tbldismissedannouncements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemaillists
#

DROP TABLE IF EXISTS `tblemaillists`;

CREATE TABLE `tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `message` text NOT NULL,
  `fromname` mediumtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('1', 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><br /></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for registering on the {companyname} CRM System.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We just wanted to say welcome.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us if you need any help.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">(This is an automated email, so please don\'t reply to this email address)</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('2', 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We have prepared the following invoice for you: #&nbsp;{invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Invoice status:&nbsp;<strong style=\"font-family: Helvetica, Arial, sans-serif;\">{invoice_status}</strong></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span>&nbsp;</div>\r\n<div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('3', 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">New support ticket has been opened.</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; color: #000000; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; color: #000000; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a><br /></span></div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"color: #000000; font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('4', 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;<span style=\"background-color: inherit;\">{contact_firstname} </span>{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have a new ticket reply to ticket #{ticket_id}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a><br /></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('5', 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {ticket_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: {ticket_priority}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('6', 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Payment recorded for invoice&nbsp;# {invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('7', 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is an overdue notice for invoice # {invoice_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This invoice was due: {invoice_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span>&nbsp;</div>\r\n<div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('8', 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'On your command here is the invoice', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi <span style=\"background-color: inherit;\">{contact_firstname} {contact_lastname}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">At your request, here is the invoice with number #{invoice_number}</span></div>\r\n<div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('9', 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new support ticket has been opened.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}<br /><br />You can view the ticket on the following link:&nbsp;<a href=\"{ticket_url}\">#{ticket_id}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('10', 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please find the attached estimate # {estimate_number}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Estimate status:&nbsp;<strong>{estimate_status}<br /><br /></strong>You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a><br /></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to your communication.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('11', 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: <span style=\"background-color: inherit;\">{ticket_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('12', 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank you for your estimate request.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('13', 'contract', 'contract-expiration', 'english', 'Contract Expiration', 'Contract Expiration Reminder', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {client_company}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {contract_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: {contract_description}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Date Start: {contract_datestart}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Date End: {contract_dateend}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Value: {contract_contract_value}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Please contact us for more information.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('14', 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have been assigned a new task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: <span style=\"background-color: #ffffff;\">{task_name}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: #ffffff;\">{task_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('15', 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task', 'You are added as follower on task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} <span style=\"background-color: #ffffff;\">{staff_lastname}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You have been added as follower on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: {task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: {task_description}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: {task_priority}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Start date: {task_startdate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: {task_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('16', 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A comment has been made on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: &nbsp;{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: &nbsp;{task_description}<br />Comment: {task_comment}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('17', 'tasks', 'task-marked-as-finished', 'english', 'Task Marked as Finished (Sent to Staff)', 'Task Marked as Finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} marked the following task as complete:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}<br /></span></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('18', 'tasks', 'task-added-attachment', 'english', 'New Attachment on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} added an attachment on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('19', 'tasks', 'task-unmarked-as-finished', 'english', 'Task Unmarked as Finished (Sent to Staff)', 'Task UN-marked as finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname} {staff_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} <span style=\"background-color: inherit;\">marked the </span>following task as <strong>in-complete / unfinished</strong></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span><span style=\"background-color: inherit;\">{task_name}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: {task_duedate}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('20', 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<div><span style=\"font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <span style=\"background-color: inherit;\">{estimate_number}</span></span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('21', 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <span style=\"background-color: inherit;\">{estimate_number}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the estimate on the following link:&nbsp;<a href=\"{estimate_link}\">{estimate_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('22', 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Client {proposal_proposal_to} accepted the following proposal:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Subject: {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Total: {proposal_total}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('23', 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal', '<div>Dear {proposal_proposal_to}</div>\r\n<div>&nbsp;</div>\r\n<div>Please find our attached proposal.</div>\r\n<div>&nbsp;</div>\r\n<div>This proposal is valid until: {proposal_open_till}</div>\r\n<div>You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></div>\r\n<div>&nbsp;</div>\r\n<div>Please don\'t hesitate to comment online if you have any questions.</div>\r\n<div>&nbsp;</div>\r\n<div>We look forward to your communication.</div>\r\n<div>&nbsp;</div>\r\n<div>Kind regards</div>\r\n<div>&nbsp;</div>\r\n<div>{email_signature}</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('24', 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer {proposal_proposal_to} declined the proposal {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">View the proposal on the following link <a href=\"{proposal_link}\">{proposal_subject}</a>&nbsp;or from the admin area.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('25', 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {proposal_proposal_to}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank for for accepting the proposal.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to doing business with you.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We will contact you as soon as possible</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('26', 'proposals', 'proposal-comment-to-client', 'english', 'New Comment  (Sent to Customer Contacts)', 'New Proposal Comment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {proposal_proposal_to}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new comment has been made on the following proposal: {proposal_subject}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('27', 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hello</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A new <strong>comment</strong> has been made to the proposal <span style=\"background-color: inherit;\">{proposal_subject}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a><span style=\"background-color: inherit;\">&nbsp;or from the admin area.</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('28', 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname}&nbsp;{contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Thank for for accepting the estimate.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We look forward to doing business with you.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">We will contact you as soon as possible.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('29', 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {staff_firstname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">This is an automated email from {companyname}.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">The task {task_name} deadline is on {task_duedate}. This task is still not finished.</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('30', 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p>Hi&nbsp;{client_company}</p>\r\n<p>Please find the {contract_subject}&nbsp;attached.</p>\r\n<p>Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('31', 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Customer recorded payment for invoice # {invoice_number}</span></div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('32', 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket&nbsp;{ticket_subject} has been auto close due to inactivity.</span></p>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Ticket #: <span style=\"background-color: inherit;\">{ticket_id}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Department: {ticket_department}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Priority: <span style=\"background-color: inherit;\">{ticket_priority}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">Ticket message:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt; background-color: inherit;\">{ticket_message}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('33', 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project discussion created from&nbsp;{discussion_creator}</p>\r\n<p>Subject:&nbsp;{discussion_subject}</p>\r\n<p>Description:&nbsp;{discussion_description}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('34', 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project discussion created from&nbsp;{discussion_creator}</p>\r\n<p>Subject:&nbsp;{discussion_subject}</p>\r\n<p>Description:&nbsp;{discussion_description}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('35', 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File Uploaded (Sent to Customer Contacts)', 'New Project File Uploaded', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;{project_name} from&nbsp;{file_creator}</p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br />To view&nbsp;the file in our CRM&nbsp;you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('36', 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File Uploaded (Sent to Project Members)', 'New Project File Uploaded', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;{project_name} from&nbsp;{file_creator}</p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('37', 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New discussion comment has been made on {discussion_subject} from&nbsp;{comment_creator}</p>\r\n<p>Discussion subject:&nbsp;{discussion_subject}</p>\r\n<p>Comment:&nbsp;{discussion_comment}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('38', 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New discussion comment has been made on {discussion_subject} from&nbsp;{comment_creator}</p>\r\n<p>Discussion subject:&nbsp;{discussion_subject}</p>\r\n<p>Comment:&nbsp;{discussion_comment}</p>\r\n<p>You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('39', 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}</p>\r\n<p>New project has been assigned to you.</p>\r\n<p>You can view the project on the following link <a href=\"{project_link}\">{project_name}</a></p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('40', 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p>Hello&nbsp;{client_company}</p>\r\n<p>The estimate with&nbsp;{estimate_number} will expire on&nbsp;{estimate_expirydate}</p>\r\n<p>You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></p>\r\n<p>Regards,</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('41', 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hello&nbsp;{proposal_proposal_to}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">The proposal {proposal_subject} will expire on&nbsp;{proposal_open_till}</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_subject}</a></span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Regards,</span></p>\r\n<p><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('42', 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />You are added as member on our CRM.<br />You can login at {admin_url}<br /><br />Please use the following&nbsp;logic credentials:<br /><br />Email:&nbsp;{staff_email}<br />Password:&nbsp;{password}<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('43', 'client', 'contact-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('44', 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong>You have changed your password.<br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('45', 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2>Setup your new password on {companyname}</h2>\r\nPlease use the following link to setup your new password.<br /><br />Keep it in your records so you don\'t forget it.<br /><br /> Please set your new password in 48 hours. After that you wont be able to set your password. <br /><br />You can login at: {crm_url}<br /> Your email address for login: {contact_email}<br /> <br /><a href=\"{set_password_url}\">Set New Password</a><br /> <br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('46', 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('47', 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong>You have changed your password.<br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('48', 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}</p>\r\n<p>New project is assigned to your company.<br />Project Name:&nbsp;{project_name}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.</p>\r\n<p>{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('49', 'tasks', 'task-marked-as-finished-to-contacts', 'english', 'Task Marked as Finished (Sent to customer contacts)', 'Task Marked as Finished - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} marked the following task as complete:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Due date: <span style=\"background-color: #ffffff;\">{task_duedate}<br /></span></span><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('50', 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{task_user_take_action} added an attachment on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Name: </span>{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\"><span style=\"background-color: inherit;\">Description: </span><span style=\"background-color: inherit;\">{task_description}</span></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-size: 12pt; font-family: arial, helvetica, sans-serif;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('51', 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">A comment has been made on the following task:</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Name: &nbsp;{task_name}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Description: &nbsp;{task_description}<br />Comment: {task_comment}</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Click on the following link to view: <a href=\"{task_link}\">{task_name}</a></span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">Kind regards,</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">&nbsp;</span></div>\r\n<div><span style=\"font-family: arial, helvetica, sans-serif; font-size: 12pt;\">{email_signature}</span></div>', '{companyname} | CRM', '', '0', '1', '0');
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES ('52', 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}</p>\r\n<p>New&nbsp;lead is assigned to you.<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}<br /><br /></a>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', '0', '1', '0');


#
# TABLE STRUCTURE FOR: tblentities
#

DROP TABLE IF EXISTS `tblentities`;

CREATE TABLE `tblentities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `entity_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `automatedExpansion` int(1) DEFAULT '0',
  `isOverridable` int(1) DEFAULT '0',
  `is_system` int(1) DEFAULT '0',
  PRIMARY KEY (`id`,`agentid`,`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('11', '1', '1', 'delivery-pickup', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('12', '1', '1', 'drink', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('13', '1', '1', 'size', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('14', '1', '1', 'iced', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('15', '1', '1', 'snack', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('16', '1', '1', 'milk-type', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('17', '1', '1', 'topping', '0', '1', '0');
INSERT INTO `tblentities` (`id`, `agentid`, `userid`, `entity_name`, `automatedExpansion`, `isOverridable`, `is_system`) VALUES ('18', '1', '1', 'flavor', '0', '1', '0');


#
# TABLE STRUCTURE FOR: tblentityreferences
#

DROP TABLE IF EXISTS `tblentityreferences`;

CREATE TABLE `tblentityreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entityid` int(11) NOT NULL,
  `reference` text COLLATE utf8_unicode_ci,
  `synonyms` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`,`entityid`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('152', '17', 'caramel', 'caramel');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('153', '17', 'whipped cream', 'whipped cream,whip');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('154', '17', 'chocolate', 'chocolate,chocolate syrup,chocolate drizzle');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('155', '17', 'cinnamon', 'cinnamon');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('156', '15', 'cupcake', 'cupcake');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('157', '15', 'caesar salad', 'caesar salad');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('158', '15', 'deep dish cake', 'deep dish cake');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('159', '15', 'mediterranean salad', 'mediterranean salad');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('160', '15', 'greek salad', 'greek salad');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('161', '15', 'danish', 'danish');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('162', '15', 'plum cake', 'plum cake');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('163', '15', 'strudel', 'strudel');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('164', '15', 'muffin', 'muffin');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('165', '15', 'doughnut', 'doughnut,donut');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('166', '15', 'carrot cake', 'carrot cake');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('167', '15', 'croissant', 'croissant');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('168', '15', 'bagel', 'bagel');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('174', '16', 'soy milk', 'soy');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('175', '16', 'non fat milk', 'non fat milk,non fat,non-fat,skinny');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('176', '16', 'cream', 'cream,half and half,half-and-half');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('177', '16', 'regular mik', 'regular,two percent,low fat,lowfat,normal,low-fat,regular mik');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('178', '16', 'almond milk', 'almond');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('179', '14', 'true', 'iced,cold,chilled,on ice');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('180', '18', 'cream cheese', 'cream cheese');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('181', '18', 'hazelnut', 'hazelnut');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('182', '18', 'blueberry', 'blueberry');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('183', '18', 'caramel', 'caramel');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('184', '18', 'almond', 'almond');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('185', '18', 'peppermint', 'peppermint');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('186', '18', 'vanilla', 'vanilla');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('187', '18', 'raspberry', 'raspberry');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('188', '18', 'sugar-free vanilla', 'sugar-free vanilla,sugar free vanilla');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('189', '12', 'latte', 'latte');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('190', '12', 'macchiato', 'macchiato');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('191', '12', 'espresso con panna', 'espresso con panna');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('192', '12', 'hot chocolate', 'hot chocolate');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('193', '12', 'espresso', 'espresso');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('194', '12', 'barista coffee', 'barista coffee');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('195', '12', 'coffee', 'coffee');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('196', '12', 'cocoa', 'cocoa');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('197', '12', 'espresso macchiato', 'espresso macchiato');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('198', '12', 'americano', 'americano');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('199', '12', 'moccacino', 'moccacino');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('200', '12', 'cappuccino', 'cappuccino');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('201', '12', 'tea', 'tea');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('202', '11', 'delivery', 'delivery,deliver,bring me');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('203', '11', 'pick-up', 'pick-up,pickup,carry out,pick up,to go,to-go');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('204', '13', 'small', 'small,little,short,tall');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('205', '13', 'large', 'large,huge,big');
INSERT INTO `tblentityreferences` (`id`, `entityid`, `reference`, `synonyms`) VALUES ('206', '13', 'medium', 'medium');


#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `total` decimal(11,2) NOT NULL,
  `adjustment` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `discount_percent` decimal(11,2) DEFAULT '0.00',
  `discount_total` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext NOT NULL,
  `description` text,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT '0',
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` text,
  `expense_name` varchar(500) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `billable` int(11) DEFAULT '0',
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `custom_recurring` int(11) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpensescategories
#

DROP TABLE IF EXISTS `tblexpensescategories`;

CREATE TABLE `tblexpensescategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(600) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformquestionboxes
#

DROP TABLE IF EXISTS `tblformquestionboxes`;

CREATE TABLE `tblformquestionboxes` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformquestionboxesdescription
#

DROP TABLE IF EXISTS `tblformquestionboxesdescription`;

CREATE TABLE `tblformquestionboxesdescription` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformquestions
#

DROP TABLE IF EXISTS `tblformquestions`;

CREATE TABLE `tblformquestions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblformresults
#

DROP TABLE IF EXISTS `tblformresults`;

CREATE TABLE `tblformresults` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblgoals
#

DROP TABLE IF EXISTS `tblgoals`;

CREATE TABLE `tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(400) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT '0',
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT '1',
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT '1',
  `notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblintentactionprompts
#

DROP TABLE IF EXISTS `tblintentactionprompts`;

CREATE TABLE `tblintentactionprompts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intentid` int(11) NOT NULL,
  `entityid` int(11) NOT NULL,
  `prompt` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`,`intentid`,`entityid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('1', '24', '9', 'What would you like to drink?');
INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('2', '24', '5', 'Small, medium or large?');
INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('3', '24', '10', 'Would you like a delivery or pick-up?');
INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('4', '5', '11', 'Would you like a delivery or pick-up?');
INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('5', '5', '12', 'What would you like to drink?');
INSERT INTO `tblintentactionprompts` (`id`, `intentid`, `entityid`, `prompt`) VALUES ('6', '5', '13', 'Small, medium or large?');


#
# TABLE STRUCTURE FOR: tblintentresponses
#

DROP TABLE IF EXISTS `tblintentresponses`;

CREATE TABLE `tblintentresponses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intentid` int(11) NOT NULL,
  `response` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`,`intentid`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('120', '2', 'hi!');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('121', '2', 'hello!');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('122', '2', 'good day!');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('123', '2', 'greetings!');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('124', '1', 'i didn\'t get that. can you say it again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('125', '1', 'i missed what you said. say it again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('126', '1', 'sorry, could you say that again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('127', '1', 'sorry, can you say that again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('128', '1', 'can you say that again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('129', '1', 'sorry, i didn\'t get that.');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('130', '1', 'sorry, what was that?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('131', '1', 'one more time?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('132', '1', 'what was that?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('133', '1', 'say that again?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('134', '1', 'i didn\'t get that.');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('135', '1', 'i missed that.');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('136', '4', 'good day! i have a lot coffee and snacks. what can i get you to drink?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('187', '5', 'your order is: $size $drink with $milk-type and you want a $delivery-pickup. is that right?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('188', '5', 'you\'ve ordered $size $drink and you want a $delivery-pickup. correct?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('189', '5', 'you want $amount $size $drink with $topping and you want a $delivery-pickup. is that right?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('190', '5', 'you want $amount $size $drink with $milk-type and you want a $delivery-pickup. is that right?');
INSERT INTO `tblintentresponses` (`id`, `intentid`, `response`) VALUES ('191', '5', 'you want $amount $size $drink and you want a $delivery-pickup. is that right?');


#
# TABLE STRUCTURE FOR: tblintents
#

DROP TABLE IF EXISTS `tblintents`;

CREATE TABLE `tblintents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `parentid` int(11) DEFAULT '0',
  `intent_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `contexts` text COLLATE utf8_unicode_ci,
  `events` text COLLATE utf8_unicode_ci,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_parameters` text CHARACTER SET utf8,
  `is_default` int(1) NOT NULL DEFAULT '0',
  `is_system` int(1) NOT NULL DEFAULT '0',
  `is_public` int(1) NOT NULL DEFAULT '0',
  `merge` int(1) DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `is_end` int(1) DEFAULT '0',
  PRIMARY KEY (`id`,`agentid`,`userid`,`intent_name`,`is_default`,`is_system`,`is_public`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('1', '0', '0', '0', 'Default Fallback Intent', NULL, NULL, 'system.fallback.intent', NULL, '1', '1', '1', '0', '1', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('2', '0', '0', '0', 'Default Welcome Intent', NULL, NULL, 'system_welcome.intent', NULL, '0', '1', '1', '0', '1', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('3', '1', '1', '0', 'Default Fallback Intent', NULL, NULL, NULL, NULL, '1', '0', '0', '0', '1', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('4', '1', '1', '0', 'Default Welcome Intent', NULL, NULL, 'input.welcome', NULL, '0', '0', '0', '0', '1', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('5', '1', '1', '0', 'order.drink', NULL, NULL, '', '[{\"is_required\":\"1\",\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"$drink\"},{\"parameter_name\":\"milk-type\",\"entity\":\"@milk-type\",\"resolved_value\":\"$drink\"},{\"parameter_name\":\"iced\",\"entity\":\"@iced\",\"resolved_value\":\"$milk-type\"},{\"is_required\":\"1\",\"parameter_name\":\"delivery-pickup\",\"entity\":\"@delivery-pickup\",\"resolved_value\":\"$milk-type\"},{\"parameter_name\":\"topping\",\"entity\":\"@topping\",\"resolved_value\":\"$drink\"},{\"is_required\":\"1\",\"parameter_name\":\"size\",\"entity\":\"@size\",\"resolved_value\":\"$size\"}]', '0', '0', '0', '0', '1', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('6', '1', '1', '0', 'order.gift_card', NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('7', '1', '1', '0', 'order.last', NULL, NULL, '', NULL, '0', '0', '0', '0', '0', '0');
INSERT INTO `tblintents` (`id`, `agentid`, `userid`, `parentid`, `intent_name`, `contexts`, `events`, `action`, `action_parameters`, `is_default`, `is_system`, `is_public`, `merge`, `status`, `is_end`) VALUES ('8', '1', '1', '0', 'order.snack', NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: tblintentusersays
#

DROP TABLE IF EXISTS `tblintentusersays`;

CREATE TABLE `tblintentusersays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intentid` int(11) NOT NULL,
  `usersay` text COLLATE utf8_unicode_ci,
  `parameters` longtext COLLATE utf8_unicode_ci,
  `parse` longtext CHARACTER SET utf8,
  PRIMARY KEY (`id`,`intentid`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('1', '4', 'hey', NULL, '[[\"hey\",\"NN\"]]');
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('2', '4', 'welcome', NULL, '[[\"welcome\",\"JJ\"]]');
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('3', '4', 'hi', NULL, '[[\"hi\",\"UH\"]]');
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('4', '4', 'hello', NULL, '[[\"hello\",\"UH\"]]');
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('105', '5', '  can i get a small iced latte with low fat milk', '[{\"parameter_name\":\"milk-type\",\"entity\":\"@milk-type\",\"resolved_value\":\"low fat\"},{\"parameter_name\":\"iced\",\"entity\":\"@iced\",\"resolved_value\":\"iced\"},{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"latte\"},{\"parameter_name\":\"size\",\"entity\":\"@size\",\"resolved_value\":\"small\"}]', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('106', '5', 'can i get tea', '{\"4\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"tea\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('107', '5', 'i\'d like to order a drink', 'null', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('108', '5', 'hot chocolate', '{\"5\":{\"parameter_name\":\"topping\",\"entity\":\"@topping\",\"resolved_value\":\"chocolate\"},\"6\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"hot chocolate\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('109', '5', 'i\'d like a coffee to go', '{\"7\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"coffee\"},\"8\":{\"parameter_name\":\"delivery-pickup\",\"entity\":\"@delivery-pickup\",\"resolved_value\":\"to go\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('110', '5', 'can i get a small iced cappuccino with low fat milk', '{\"9\":{\"parameter_name\":\"milk-type\",\"entity\":\"@milk-type\",\"resolved_value\":\"low fat\"},\"10\":{\"parameter_name\":\"iced\",\"entity\":\"@iced\",\"resolved_value\":\"iced\"},\"11\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"cappuccino\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('111', '5', 'can i get a huge cup of macchiato', '{\"12\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"macchiato\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('112', '5', 'some tea please', '{\"13\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"tea\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('113', '5', 'i need a cup of coffee', '{\"14\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"coffee\"}}', NULL);
INSERT INTO `tblintentusersays` (`id`, `intentid`, `usersay`, `parameters`, `parse`) VALUES ('114', '5', 'people need coffee', '{\"15\":{\"parameter_name\":\"drink\",\"entity\":\"@drink\",\"resolved_value\":\"coffee\"}}', NULL);


#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentsmodes
#

DROP TABLE IF EXISTS `tblinvoicepaymentsmodes`;

CREATE TABLE `tblinvoicepaymentsmodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `invoices_only` int(11) NOT NULL DEFAULT '0',
  `expenses_only` int(11) NOT NULL DEFAULT '0',
  `selected_by_default` int(11) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblinvoicepaymentsmodes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES ('1', 'Bank', NULL, '0', '0', '0', '1', '1');


#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `total` decimal(11,2) NOT NULL,
  `adjustment` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `last_overdue_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT '0',
  `allowed_payment_modes` mediumtext,
  `token` mediumtext,
  `discount_percent` decimal(11,2) DEFAULT '0.00',
  `discount_total` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` text,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `long_description` text,
  `rate` decimal(11,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems_in
#

DROP TABLE IF EXISTS `tblitems_in`;

CREATE TABLE `tblitems_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` mediumtext,
  `qty` decimal(11,2) NOT NULL,
  `rate` decimal(11,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemsrelated
#

DROP TABLE IF EXISTS `tblitemsrelated`;

CREATE TABLE `tblitemsrelated` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemstax
#

DROP TABLE IF EXISTS `tblitemstax`;

CREATE TABLE `tblitemstax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(11,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebase
#

DROP TABLE IF EXISTS `tblknowledgebase`;

CREATE TABLE `tblknowledgebase` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT '0',
  `staff_article` int(11) NOT NULL DEFAULT '0',
  `views` int(11) DEFAULT NULL,
  PRIMARY KEY (`articleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebasearticleanswers
#

DROP TABLE IF EXISTS `tblknowledgebasearticleanswers`;

CREATE TABLE `tblknowledgebasearticleanswers` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledgebasegroups
#

DROP TABLE IF EXISTS `tblknowledgebasegroups`;

CREATE TABLE `tblknowledgebasegroups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `description` mediumtext,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadactivitylog
#

DROP TABLE IF EXISTS `tblleadactivitylog`;

CREATE TABLE `tblleadactivitylog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` varchar(600) DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(300) DEFAULT NULL,
  `description` text,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT '1',
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT '0',
  `junk` int(11) NOT NULL DEFAULT '0',
  `last_lead_status` int(11) NOT NULL DEFAULT '0',
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `assigned` (`assigned`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `leadorder` (`leadorder`),
  KEY `dateadded` (`dateadded`),
  KEY `from_form_id` (`from_form_id`),
  KEY `from_form_id_2` (`from_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadsemailintegrationemails
#

DROP TABLE IF EXISTS `tblleadsemailintegrationemails`;

CREATE TABLE `tblleadsemailintegrationemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext,
  `body` mediumtext,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadsintegration
#

DROP TABLE IF EXISTS `tblleadsintegration`;

CREATE TABLE `tblleadsintegration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` mediumtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT '5',
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT '1',
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT '1',
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadsintegration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `only_loop_on_unseen_emails`, `delete_after_import`) VALUES ('1', '0', '', '', '', '10', '0', '0', '0', 'tls', 'inbox', '', '1', '1', 'roles', '', '1', '0');


#
# TABLE STRUCTURE FOR: tblleadssources
#

DROP TABLE IF EXISTS `tblleadssources`;

CREATE TABLE `tblleadssources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadssources` (`id`, `name`) VALUES ('1', 'Google');
INSERT INTO `tblleadssources` (`id`, `name`) VALUES ('2', 'Facebook');


#
# TABLE STRUCTURE FOR: tblleadsstatus
#

DROP TABLE IF EXISTS `tblleadsstatus`;

CREATE TABLE `tblleadsstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleadsstatus` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES ('1', 'Customer', '1000', '#7cb342', '1');


#
# TABLE STRUCTURE FOR: tbllistemails
#

DROP TABLE IF EXISTS `tbllistemails`;

CREATE TABLE `tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfields
#

DROP TABLE IF EXISTS `tblmaillistscustomfields`;

CREATE TABLE `tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfieldvalues
#

DROP TABLE IF EXISTS `tblmaillistscustomfieldvalues`;

CREATE TABLE `tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblmigrations` (`version`) VALUES ('161');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) NOT NULL,
  `description` text,
  `description_visible_to_customer` tinyint(1) DEFAULT '0',
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `datecreated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` text,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext,
  `additional_data` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('1', 'dateformat', 'Y-m-d|%Y-%m-%d');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('2', 'companyname', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('3', 'services', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('4', 'maximum_allowed_ticket_attachments', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('5', 'ticket_attachments_file_extensions', '.jpg,.png,.pdf,.doc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('6', 'staff_access_only_assigned_departments', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('7', 'use_knowledge_base', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('8', 'smtp_email', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('9', 'smtp_password', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('10', 'smtp_port', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('11', 'smtp_host', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('12', 'smtp_email_charset', 'utf-8');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('13', 'default_timezone', 'Europe/Belgrade');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('14', 'clients_default_theme', 'echelon');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('15', 'company_logo', 'logo.png');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('16', 'tables_pagination_limit', '25');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('17', 'main_domain', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('18', 'allow_registration', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('19', 'knowledge_base_without_registration', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('20', 'email_signature', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('21', 'default_staff_role', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('22', 'newsfeed_maximum_files_upload', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('23', 'newsfeed_maximum_file_size', '5');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('24', 'contract_expiration_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('25', 'invoice_prefix', 'INV-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('26', 'decimal_separator', '.');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('27', 'thousand_separator', ',');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('28', 'currency_placement', 'before');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('29', 'invoice_company_name', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('30', 'invoice_company_address', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('31', 'invoice_company_city', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('32', 'invoice_company_country_code', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('33', 'invoice_company_postal_code', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('34', 'invoice_company_phonenumber', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('35', 'view_invoice_only_logged_in', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('36', 'invoice_number_format', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('37', 'next_invoice_number', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('38', 'cron_send_invoice_overdue_reminder', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('39', 'active_language', 'english');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('40', 'invoice_number_decrement_on_delete', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('41', 'automatically_send_invoice_overdue_reminder_after', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('42', 'automatically_resend_invoice_overdue_reminder_after', '3');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('43', 'expenses_auto_operations_hour', '21');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('44', 'survey_send_emails_per_cron_run', '100');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('45', 'delete_only_on_last_invoice', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('46', 'delete_only_on_last_estimate', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('47', 'create_invoice_from_recurring_only_on_paid_invoices', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('48', 'allow_payment_amount_to_be_modified', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('49', 'send_renewed_invoice_from_recurring_to_email', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('50', 'rtl_support_client', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('51', 'limit_top_search_bar_results_to', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('52', 'estimate_prefix', 'EST-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('53', 'next_estimate_number', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('54', 'estimate_number_decrement_on_delete', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('55', 'estimate_number_format', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('56', 'estimate_auto_convert_to_invoice_on_client_accept', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('57', 'exclude_estimate_from_client_area_with_draft_status', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('58', 'rtl_support_admin', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('59', 'last_cron_run', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('60', 'show_sale_agent_on_estimates', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('61', 'show_sale_agent_on_invoices', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('62', 'predefined_terms_invoice', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('63', 'predefined_terms_estimate', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('64', 'default_task_priority', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('65', 'dropbox_app_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('66', 'show_expense_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('67', 'only_show_contact_tickets', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('68', 'predefined_clientnote_invoice', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('69', 'predefined_clientnote_estimate', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('70', 'custom_pdf_logo_image_url', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('71', 'favicon', 'favicon.ico');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('72', 'auto_backup_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('73', 'invoice_due_after', '30');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('74', 'google_api_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('75', 'google_calendar_main_calendar', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('76', 'default_tax', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('77', 'show_invoices_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('78', 'show_estimates_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('79', 'show_contracts_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('80', 'show_tasks_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('81', 'show_customer_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('82', 'auto_backup_every', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('83', 'last_auto_backup', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('84', 'output_client_pdfs_from_admin_area_in_client_language', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('85', 'show_lead_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('86', 'aside_menu_active', '{\"aside_menu_active\":[{\"name\":\"als_dashboard\",\"url\":\"\\/\",\"permission\":\"\",\"icon\":\"fa fa-tachometer\",\"id\":\"dashboard\"},{\"name\":\"als_clients\",\"url\":\"clients\",\"permission\":\"customers\",\"icon\":\"fa fa-users\",\"id\":\"customers\"},{\"id\":\"echelon\",\"name\":\"als_echelon\",\"url\":\"#\",\"permission\":\"\",\"icon\":\"fa fa-cube\",\"children\":[{\"name\":\"als_intents\",\"url\":\"intents\",\"permission\":\"intents\",\"icon\":\"fa fa-comments-o\",\"id\":\"intents\"},{\"name\":\"als_entities\",\"url\":\"entities\",\"permission\":\"entities\",\"icon\":\"fa fa-sitemap\",\"id\":\"entities\"}]},{\"name\":\"projects\",\"url\":\"projects\",\"permission\":\"\",\"icon\":\"fa fa-bars\",\"id\":\"projects\"},{\"name\":\"als_sales\",\"url\":\"#\",\"permission\":\"\",\"icon\":\"fa fa-balance-scale\",\"id\":\"sales\",\"children\":[{\"name\":\"proposals\",\"url\":\"proposals\",\"permission\":\"proposals\",\"icon\":\"\",\"id\":\"child-proposals\"},{\"name\":\"estimates\",\"url\":\"estimates\\/list_estimates\",\"permission\":\"estimates\",\"icon\":\"\",\"id\":\"child-estimates\"},{\"name\":\"invoices\",\"url\":\"invoices\\/list_invoices\",\"permission\":\"invoices\",\"icon\":\"\",\"id\":\"child-invoices\"},{\"name\":\"payments\",\"url\":\"payments\",\"permission\":\"payments\",\"icon\":\"\",\"id\":\"child-payments\"},{\"name\":\"items\",\"url\":\"invoice_items\",\"permission\":\"items\",\"icon\":\"\",\"id\":\"child-items\"}]},{\"name\":\"als_expenses\",\"url\":\"expenses\\/list_expenses\",\"permission\":\"expenses\",\"icon\":\"fa fa-heartbeat\",\"id\":\"expenses\"},{\"name\":\"support\",\"url\":\"tickets\",\"permission\":\"\",\"icon\":\"fa fa-ticket\",\"id\":\"tickets\"},{\"name\":\"als_contracts\",\"url\":\"contracts\",\"permission\":\"contracts\",\"icon\":\"fa fa-file\",\"id\":\"contracts\"},{\"name\":\"als_leads\",\"url\":\"leads\",\"permission\":\"is_staff_member\",\"icon\":\"fa fa-tty\",\"id\":\"leads\"},{\"name\":\"als_tasks\",\"url\":\"tasks\\/list_tasks\",\"permission\":\"\",\"icon\":\"fa fa-tasks\",\"id\":\"tasks\"},{\"name\":\"als_kb\",\"url\":\"#\",\"permission\":\"knowledge_base\",\"icon\":\"fa fa-folder-open-o\",\"id\":\"knowledge-base\",\"children\":[{\"name\":\"als_all_articles\",\"url\":\"knowledge_base\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-all-articles\"},{\"name\":\"als_kb_groups\",\"url\":\"knowledge_base\\/manage_groups\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-groups\"}]},{\"name\":\"als_reports\",\"url\":\"#\",\"permission\":\"reports\",\"icon\":\"fa fa-area-chart\",\"id\":\"reports\",\"children\":[{\"name\":\"als_reports_sales_submenu\",\"url\":\"reports\\/sales\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-sales\"},{\"name\":\"als_reports_expenses\",\"url\":\"reports\\/expenses\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-expenses\"},{\"name\":\"als_expenses_vs_income\",\"url\":\"reports\\/expenses_vs_income\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-expenses-vs-income\"},{\"name\":\"als_reports_leads_submenu\",\"url\":\"reports\\/leads\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-leads\"},{\"name\":\"als_kb_articles_submenu\",\"url\":\"reports\\/knowledge_base_articles\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-kb-articles\"}]},{\"name\":\"als_utilities\",\"url\":\"#\",\"permission\":\"\",\"icon\":\"fa fa-cogs\",\"id\":\"utilities\",\"children\":[{\"name\":\"als_media\",\"url\":\"utilities\\/media\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-media\"},{\"name\":\"bulk_pdf_exporter\",\"url\":\"utilities\\/bulk_pdf_exporter\",\"permission\":\"bulk_pdf_exporter\",\"icon\":\"\",\"id\":\"child-bulk-pdf-exporter\"},{\"name\":\"als_calendar_submenu\",\"url\":\"utilities\\/calendar\",\"permission\":\"\",\"icon\":\"\",\"id\":\"child-calendar\"},{\"name\":\"als_goals_tracking\",\"url\":\"goals\",\"permission\":\"goals\",\"icon\":\"\",\"id\":\"child-goals-tracking\"},{\"name\":\"als_surveys\",\"url\":\"surveys\",\"permission\":\"surveys\",\"icon\":\"\",\"id\":\"child-surveys\"},{\"name\":\"als_announcements_submenu\",\"url\":\"announcements\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-announcements\"},{\"name\":\"utility_backup\",\"url\":\"utilities\\/backup\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-database-backup\"},{\"name\":\"als_activity_log_submenu\",\"url\":\"utilities\\/activity_log\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"child-activity-log\"},{\"name\":\"ticket_pipe_log\",\"url\":\"utilities\\/pipe_log\",\"permission\":\"is_admin\",\"icon\":\"\",\"id\":\"ticket-pipe-log\"}]}]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('87', 'estimate_expiry_reminder_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('88', 'send_estimate_expiry_reminder_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('89', 'leads_default_source', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('90', 'leads_default_status', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('91', 'proposal_expiry_reminder_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('92', 'send_proposal_expiry_reminder_before', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('93', 'default_contact_permissions', 'a:0:{}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('94', 'pdf_logo_width', '150');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('95', 'aside_menu_inactive', '{\"aside_menu_inactive\":[]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('96', 'setup_menu_active', '{\"setup_menu_active\":[{\"permission\":\"staff\",\"name\":\"als_staff\",\"url\":\"staff\",\"icon\":\"\",\"id\":\"staff\"},{\"permission\":\"is_admin\",\"name\":\"clients\",\"url\":\"#\",\"icon\":\"\",\"id\":\"customers\",\"children\":[{\"permission\":\"\",\"name\":\"customer_groups\",\"url\":\"clients\\/groups\",\"icon\":\"\",\"id\":\"groups\"}]},{\"permission\":\"\",\"name\":\"support\",\"url\":\"#\",\"icon\":\"\",\"id\":\"tickets\",\"children\":[{\"permission\":\"is_admin\",\"name\":\"acs_departments\",\"url\":\"departments\",\"icon\":\"\",\"id\":\"departments\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_predefined_replies_submenu\",\"url\":\"tickets\\/predifined_replies\",\"icon\":\"\",\"id\":\"predifined-replies\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_priority_submenu\",\"url\":\"tickets\\/priorities\",\"icon\":\"\",\"id\":\"ticket-priority\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_statuses_submenu\",\"url\":\"tickets\\/statuses\",\"icon\":\"\",\"id\":\"ticket-statuses\"},{\"permission\":\"is_admin\",\"name\":\"acs_ticket_services_submenu\",\"url\":\"tickets\\/services\",\"icon\":\"\",\"id\":\"services\"},{\"permission\":\"is_admin\",\"name\":\"spam_filters\",\"url\":\"tickets\\/spam_filters\",\"icon\":\"\",\"id\":\"spam-filters\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_leads\",\"url\":\"#\",\"icon\":\"\",\"id\":\"leads\",\"children\":[{\"permission\":\"\",\"name\":\"acs_leads_sources_submenu\",\"url\":\"leads\\/sources\",\"icon\":\"\",\"id\":\"sources\"},{\"permission\":\"\",\"name\":\"acs_leads_statuses_submenu\",\"url\":\"leads\\/statuses\",\"icon\":\"\",\"id\":\"statuses\"},{\"permission\":\"\",\"name\":\"leads_email_integration\",\"url\":\"leads\\/email_integration\",\"icon\":\"\",\"id\":\"email-integration\"},{\"name\":\"web_to_lead\",\"permission\":\"is_admin\",\"icon\":\"\",\"url\":\"leads\\/forms\",\"id\":\"web-to-lead\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_finance\",\"url\":\"#\",\"icon\":\"\",\"id\":\"finance\",\"children\":[{\"permission\":\"\",\"name\":\"acs_sales_taxes_submenu\",\"url\":\"taxes\",\"icon\":\"\",\"id\":\"taxes\"},{\"permission\":\"\",\"name\":\"acs_sales_currencies_submenu\",\"url\":\"currencies\",\"icon\":\"\",\"id\":\"currencies\"},{\"permission\":\"\",\"name\":\"acs_sales_payment_modes_submenu\",\"url\":\"paymentmodes\",\"icon\":\"\",\"id\":\"payment-modes\"},{\"permission\":\"\",\"name\":\"acs_expense_categories\",\"url\":\"expenses\\/categories\",\"icon\":\"\",\"id\":\"expenses-categories\"}]},{\"permission\":\"is_admin\",\"name\":\"acs_contracts\",\"url\":\"#\",\"icon\":\"\",\"id\":\"contracts\",\"children\":[{\"permission\":\"\",\"name\":\"acs_contract_types\",\"url\":\"contracts\\/types\",\"icon\":\"\",\"id\":\"contract-types\"}]},{\"permission\":\"email_templates\",\"name\":\"acs_email_templates\",\"url\":\"emails\",\"icon\":\"\",\"id\":\"email-templates\"},{\"permission\":\"is_admin\",\"name\":\"asc_custom_fields\",\"url\":\"custom_fields\",\"icon\":\"\",\"id\":\"custom-fields\"},{\"permission\":\"roles\",\"name\":\"acs_roles\",\"url\":\"roles\",\"icon\":\"\",\"id\":\"roles\"},{\"permission\":\"is_admin\",\"name\":\"menu_builder\",\"url\":\"#\",\"icon\":\"\",\"id\":\"menu-builder\",\"children\":[{\"permission\":\"\",\"name\":\"main_menu\",\"url\":\"utilities\\/main_menu\",\"icon\":\"\",\"id\":\"organize-sidebar\"},{\"permission\":\"is_admin\",\"name\":\"setup_menu\",\"url\":\"utilities\\/setup_menu\",\"icon\":\"\",\"id\":\"setup-menu\"}]},{\"name\":\"theme_style\",\"permission\":\"is_admin\",\"icon\":\"\",\"url\":\"utilities\\/theme_style\",\"id\":\"theme-style\"},{\"permission\":\"settings\",\"name\":\"acs_settings\",\"url\":\"settings\",\"icon\":\"\",\"id\":\"settings\"}]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('97', 'access_tickets_to_none_staff_members', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('98', 'setup_menu_inactive', '{\"setup_menu_inactive\":[]}');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('99', 'customer_default_country', '196');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('100', 'view_estimate_only_logged_in', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('101', 'show_status_on_pdf_ei', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('102', 'email_piping_only_replies', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('103', 'email_piping_only_registered', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('104', 'default_view_calendar', 'month');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('105', 'email_piping_default_priority', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('106', 'total_to_words_lowercase', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('107', 'show_tax_per_item', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('108', 'last_survey_send_cron', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('109', 'total_to_words_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('110', 'receive_notification_on_new_ticket', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('111', 'autoclose_tickets_after', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('112', 'media_max_file_size_upload', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('113', 'client_staff_add_edit_delete_task_comments_first_hour', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('114', 'show_projects_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('115', 'leads_kanban_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('116', 'tasks_reminder_notification_before', '2');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('117', 'pdf_font', 'freesans');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('118', 'pdf_table_heading_color', '#323a45');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('119', 'pdf_table_heading_text_color', '#ffffff');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('120', 'pdf_font_size', '10');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('121', 'defaut_leads_kanban_sort', 'leadorder');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('122', 'defaut_leads_kanban_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('123', 'allowed_files', '.gif,.png,.jpeg,.jpg,.pdf,.doc,.txt,.docx,.xls,.zip,.rar,.xls,.mp4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('124', 'show_all_tasks_for_project_member', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('125', 'email_protocol', 'smtp');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('126', 'calendar_first_day', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('127', 'recaptcha_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('128', 'show_help_on_setup_menu', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('129', 'show_proposals_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('130', 'smtp_encryption', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('131', 'recaptcha_site_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('132', 'smtp_username', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('133', 'auto_stop_tasks_timers_on_new_timer', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('134', 'notification_when_customer_pay_invoice', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('135', 'theme_style', '[]');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('136', 'calendar_invoice_color', '#FF6F00');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('137', 'calendar_estimate_color', '#FF6F00');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('138', 'calendar_proposal_color', '#84c529');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('139', 'calendar_task_color', '#FC2D42');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('140', 'calendar_reminder_color', '#03A9F4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('141', 'calendar_contract_color', '#B72974');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('142', 'calendar_project_color', '#B72974');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('143', 'update_info_message', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('144', 'show_estimate_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('145', 'show_invoice_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('146', 'show_proposal_reminders_on_calendar', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('147', 'proposal_due_after', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('148', 'allow_customer_to_change_ticket_status', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('149', 'lead_lock_after_convert_to_customer', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('150', 'default_proposals_pipeline_sort', 'pipeline_order');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('151', 'defaut_proposals_pipeline_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('152', 'default_estimates_pipeline_sort', 'pipeline_order');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('153', 'defaut_estimates_pipeline_sort_type', 'asc');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('154', 'use_recaptcha_customers_area', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('155', 'remove_decimals_on_zero', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('156', 'remove_tax_name_from_item_table', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('157', 'pdf_format_invoice', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('158', 'pdf_format_estimate', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('159', 'pdf_format_proposal', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('160', 'pdf_format_payment', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('161', 'pdf_format_contract', 'A4-PORTRAIT');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('162', 'pdf_text_color', '#000000');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('163', 'auto_check_for_new_notifications', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('164', 'swap_pdf_info', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('165', 'exclude_invoice_from_client_area_with_draft_status', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('166', 'cron_has_run_from_cli', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('167', 'hide_cron_is_required_message', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('168', 'auto_assign_customer_admin_after_lead_convert', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('169', 'show_transactions_on_invoice_pdf', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('170', 'show_pay_link_to_invoice_pdf', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('171', 'tasks_kanban_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('172', 'purchase_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('173', 'estimates_pipeline_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('174', 'proposals_pipeline_limit', '50');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('175', 'proposal_number_prefix', 'PRO-');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('176', 'number_padding_prefixes', '6');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('177', 'show_page_number_on_pdf', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('178', 'calendar_events_limit', '4');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('179', 'show_setup_menu_item_only_on_hover', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('180', 'company_requires_vat_number_field', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('181', 'company_is_required', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('182', 'allow_contact_to_delete_files', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('183', 'company_vat', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('184', 'di', '1519557893');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('185', 'invoice_auto_operations_hour', '21');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('186', 'use_minified_files', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('187', 'only_own_files_contacts', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('188', 'allow_primary_contact_to_view_edit_billing_and_shipping', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('189', 'estimate_due_after', '7');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('190', 'delete_backups_older_then', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('191', 'staff_members_open_tickets_to_all_contacts', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('192', 'paymentmethod_authorize_aim_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('193', 'paymentmethod_authorize_aim_label', 'Authorize.net');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('194', 'paymentmethod_authorize_aim_api_login_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('195', 'paymentmethod_authorize_aim_api_transaction_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('196', 'paymentmethod_authorize_aim_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('197', 'paymentmethod_authorize_aim_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('198', 'paymentmethod_authorize_aim_test_mode_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('199', 'paymentmethod_authorize_aim_developer_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('200', 'paymentmethod_authorize_sim_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('201', 'paymentmethod_authorize_sim_label', 'Authorize.net');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('202', 'paymentmethod_authorize_sim_api_login_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('203', 'paymentmethod_authorize_sim_api_transaction_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('204', 'paymentmethod_authorize_sim_api_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('205', 'paymentmethod_authorize_sim_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('206', 'paymentmethod_authorize_sim_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('207', 'paymentmethod_authorize_sim_test_mode_enabled', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('208', 'paymentmethod_authorize_sim_developer_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('209', 'paymentmethod_mollie_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('210', 'paymentmethod_mollie_label', 'Mollie');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('211', 'paymentmethod_mollie_api_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('212', 'paymentmethod_mollie_currencies', 'EUR');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('213', 'paymentmethod_mollie_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('214', 'paymentmethod_mollie_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('215', 'paymentmethod_paypal_braintree_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('216', 'paymentmethod_paypal_braintree_label', 'Braintree');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('217', 'paymentmethod_paypal_braintree_merchant_id', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('218', 'paymentmethod_paypal_braintree_api_public_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('219', 'paymentmethod_paypal_braintree_api_private_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('220', 'paymentmethod_paypal_braintree_currencies', 'USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('221', 'paymentmethod_paypal_braintree_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('222', 'paymentmethod_paypal_braintree_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('223', 'paymentmethod_paypal_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('224', 'paymentmethod_paypal_label', 'Paypal');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('225', 'paymentmethod_paypal_username', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('226', 'paymentmethod_paypal_password', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('227', 'paymentmethod_paypal_signature', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('228', 'paymentmethod_paypal_currencies', 'EUR,USD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('229', 'paymentmethod_paypal_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('230', 'paymentmethod_paypal_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('231', 'paymentmethod_stripe_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('232', 'paymentmethod_stripe_label', 'Stripe');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('233', 'paymentmethod_stripe_api_secret_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('234', 'paymentmethod_stripe_api_publishable_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('235', 'paymentmethod_stripe_currencies', 'USD,CAD');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('236', 'paymentmethod_stripe_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('237', 'paymentmethod_stripe_test_mode_enabled', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('238', 'paymentmethod_two_checkout_active', '0');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('239', 'paymentmethod_two_checkout_label', '2Checkout');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('240', 'paymentmethod_two_checkout_account_number', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('241', 'paymentmethod_two_checkout_private_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('242', 'paymentmethod_two_checkout_publishable_key', '');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('243', 'paymentmethod_two_checkout_currencies', 'USD,EUR');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('244', 'paymentmethod_two_checkout_default_selected', '1');
INSERT INTO `tbloptions` (`id`, `name`, `value`) VALUES ('245', 'paymentmethod_two_checkout_test_mode_enabled', '1');


#
# TABLE STRUCTURE FOR: tblpermissions
#

DROP TABLE IF EXISTS `tblpermissions`;

CREATE TABLE `tblpermissions` (
  `permissionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `shortname` mediumtext NOT NULL,
  PRIMARY KEY (`permissionid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('1', 'Contracts', 'contracts');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('2', 'Tasks', 'tasks');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('3', 'Reports', 'reports');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('4', 'Settings', 'settings');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('5', 'Projects', 'projects');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('6', 'Surveys', 'surveys');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('7', 'Staff', 'staff');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('8', 'Customers', 'customers');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('9', 'Email Templates', 'email_templates');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('10', 'Roles', 'roles');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('11', 'Estimates', 'estimates');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('12', 'Knowledge base', 'knowledge_base');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('13', 'Proposals', 'proposals');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('14', 'Goals', 'goals');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('15', 'Expenses', 'expenses');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('16', 'Bulk PDF Exporter', 'bulk_pdf_exporter');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('17', 'Payments', 'payments');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('18', 'Invoices', 'invoices');
INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES ('19', 'Items', 'items');


#
# TABLE STRUCTURE FOR: tblpinnedprojects
#

DROP TABLE IF EXISTS `tblpinnedprojects`;

CREATE TABLE `tblpinnedprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpostcomments
#

DROP TABLE IF EXISTS `tblpostcomments`;

CREATE TABLE `tblpostcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpostlikes
#

DROP TABLE IF EXISTS `tblpostlikes`;

CREATE TABLE `tblpostlikes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblposts
#

DROP TABLE IF EXISTS `tblposts`;

CREATE TABLE `tblposts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpredifinedreplies
#

DROP TABLE IF EXISTS `tblpredifinedreplies`;

CREATE TABLE `tblpredifinedreplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpriorities
#

DROP TABLE IF EXISTS `tblpriorities`;

CREATE TABLE `tblpriorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('1', 'Low');
INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('2', 'Medium');
INSERT INTO `tblpriorities` (`priorityid`, `name`) VALUES ('3', 'High');


#
# TABLE STRUCTURE FOR: tblprojectactivity
#

DROP TABLE IF EXISTS `tblprojectactivity`;

CREATE TABLE `tblprojectactivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `description_key` varchar(500) NOT NULL COMMENT 'Language file key',
  `additional_data` text,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `fullname` varchar(300) DEFAULT NULL,
  `file_name` varchar(300) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectfiles
#

DROP TABLE IF EXISTS `tblprojectfiles`;

CREATE TABLE `tblprojectfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` mediumtext NOT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `description` text,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT '0',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectmembers
#

DROP TABLE IF EXISTS `tblprojectmembers`;

CREATE TABLE `tblprojectmembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectnotes
#

DROP TABLE IF EXISTS `tblprojectnotes`;

CREATE TABLE `tblprojectnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `description` text,
  `status` int(11) NOT NULL DEFAULT '0',
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `progress_from_tasks` int(11) NOT NULL DEFAULT '1',
  `project_cost` decimal(11,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(11,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectsettings
#

DROP TABLE IF EXISTS `tblprojectsettings`;

CREATE TABLE `tblprojectsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposalcomments
#

DROP TABLE IF EXISTS `tblproposalcomments`;

CREATE TABLE `tblproposalcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(500) DEFAULT NULL,
  `content` longtext,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adjustment` decimal(11,2) DEFAULT NULL,
  `discount_percent` decimal(11,2) NOT NULL,
  `discount_total` decimal(11,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(600) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT '0',
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT '1',
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblrolepermissions
#

DROP TABLE IF EXISTS `tblrolepermissions`;

CREATE TABLE `tblrolepermissions` (
  `rolepermissionid` int(11) NOT NULL AUTO_INCREMENT,
  `roleid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `permissionid` int(11) NOT NULL,
  PRIMARY KEY (`rolepermissionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblroles` (`roleid`, `name`) VALUES ('1', 'Employee');


#
# TABLE STRUCTURE FOR: tblsalesactivity
#

DROP TABLE IF EXISTS `tblsalesactivity`;

CREATE TABLE `tblsalesactivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `additional_data` varchar(600) DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o4a9u7sdsls6e3tqqgu97sl4iq65hii0', '127.0.0.1', '1519559142', '__ci_last_regenerate|i:1519559142;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:27:\"Backup is made successfully\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm0vubvq2g9soc2td4pkqh1b1tr4bapa', '127.0.0.1', '1519559559', '__ci_last_regenerate|i:1519559559;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5hlp7u1v25br6tm85p84jh2taipu666o', '127.0.0.1', '1519559911', '__ci_last_regenerate|i:1519559911;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fbdsjvvgvljdt4pt2sg835bp6cnn3j5', '127.0.0.1', '1519560212', '__ci_last_regenerate|i:1519560212;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s5858m8rupqt1v7vio5p7edfs8mktgpe', '127.0.0.1', '1519561829', '__ci_last_regenerate|i:1519561829;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gmb9qt0gkb5vainivl45f72h3q7ivdhb', '127.0.0.1', '1519562236', '__ci_last_regenerate|i:1519562236;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ghvpvv76lkk9sjn4kcnc9sjovvlnp64a', '127.0.0.1', '1519562549', '__ci_last_regenerate|i:1519562549;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hf8fg7vei0bmgfblm36o20eeu326uer1', '127.0.0.1', '1519563209', '__ci_last_regenerate|i:1519563209;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('duo5diehdpkm6gd8adi3kb386ksmkh87', '127.0.0.1', '1519563634', '__ci_last_regenerate|i:1519563634;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65cilboe6vd5r8prunk69vj37uvk01ep', '127.0.0.1', '1519564043', '__ci_last_regenerate|i:1519564043;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o06in4i62ftugkaoubgcn7m9b6vhdvbr', '127.0.0.1', '1519564366', '__ci_last_regenerate|i:1519564366;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5b4l59nnlaj1l2463sdcrmma4f2ur54p', '127.0.0.1', '1519572494', '__ci_last_regenerate|i:1519572494;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qa6cioekfap84s9s7kgoip54bjf6gki6', '127.0.0.1', '1519572831', '__ci_last_regenerate|i:1519572831;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h2ebk7olet8hut824skcc701kan6vho5', '127.0.0.1', '1519573152', '__ci_last_regenerate|i:1519573152;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jus6aohl14tu6sn9d4ni57uaugd6igh7', '127.0.0.1', '1519573545', '__ci_last_regenerate|i:1519573545;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0inodclv51eqn2qnt3jh7eu3n9387cur', '127.0.0.1', '1519573918', '__ci_last_regenerate|i:1519573918;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p5pq8u7io7uq2kl8hf5s4u9jv0hckbrp', '127.0.0.1', '1519574340', '__ci_last_regenerate|i:1519574340;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfv2674pbk1v0965vb2l3vmkdo191gpd', '127.0.0.1', '1519574647', '__ci_last_regenerate|i:1519574647;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2i1m7tp5n93g9jmklj68e9onenlkrhgp', '127.0.0.1', '1519575092', '__ci_last_regenerate|i:1519575092;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cd25po6kq2vnc1k2sk1ia23hqgfpdj5', '127.0.0.1', '1519575505', '__ci_last_regenerate|i:1519575505;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1q19ps0mnf8omghpj54j8mfr6dv6egdg', '127.0.0.1', '1519575814', '__ci_last_regenerate|i:1519575814;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6sff8qfj86tn4nph9qv5j0qkm0c0lsft', '127.0.0.1', '1519576142', '__ci_last_regenerate|i:1519576142;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4r7g8fa9q1sbp0l9mbptmrpvtbpn4ig1', '127.0.0.1', '1519576727', '__ci_last_regenerate|i:1519576727;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gsv9noghj5lahfgb46i631bdobrbfts9', '127.0.0.1', '1519577084', '__ci_last_regenerate|i:1519577084;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lk6ug0jed05532jj0h9casnh5vefq71q', '127.0.0.1', '1519578318', '__ci_last_regenerate|i:1519578318;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qahq2juslmb3i9q65tbqk6vtjvupehe5', '127.0.0.1', '1519578795', '__ci_last_regenerate|i:1519578795;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hool9hvh0rqotajga2acp3uhfv52ftpn', '127.0.0.1', '1519579371', '__ci_last_regenerate|i:1519579371;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h5j208vf2eo2pnkcuo1kn8gn1f2mr5ol', '127.0.0.1', '1519580213', '__ci_last_regenerate|i:1519580213;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:28:\"Entities added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2jdl5m1rmv72fds87hh3p4nr2n6dajl', '127.0.0.1', '1519580556', '__ci_last_regenerate|i:1519580556;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3mvlf9fc12fhpe5f6vprrbkburn4q5tv', '127.0.0.1', '1519581130', '__ci_last_regenerate|i:1519581130;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:28:\"Entities added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0val8ohht0gdgl57gjmfnebei0cmatn', '127.0.0.1', '1519581530', '__ci_last_regenerate|i:1519581530;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hf6tnn2s73rm0d26khuf5gvs110n2snh', '127.0.0.1', '1519581940', '__ci_last_regenerate|i:1519581940;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h5l54d51c8a0dfrkh9sv2o08d6d5248l', '127.0.0.1', '1519582390', '__ci_last_regenerate|i:1519582390;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7k237segplq930mre83h4on3hktomnkg', '127.0.0.1', '1519582772', '__ci_last_regenerate|i:1519582772;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2m5v94it0oq17nl8c8hbhumgtf4ktk8r', '127.0.0.1', '1519583527', '__ci_last_regenerate|i:1519583527;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j9up5ah56fc6rgdcrhua6ep2vkic360d', '127.0.0.1', '1519583951', '__ci_last_regenerate|i:1519583951;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5b2q8js2esca5fi39k6lhgp2i2v2lqgv', '127.0.0.1', '1519584701', '__ci_last_regenerate|i:1519584701;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2358defngpge2a5dimtb6c43e2rebrhn', '127.0.0.1', '1519585009', '__ci_last_regenerate|i:1519585009;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ga25l3msokmt68c94604t0aveehasf3m', '127.0.0.1', '1519585335', '__ci_last_regenerate|i:1519585335;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t8tbrui6v4cjnvr2eg366tv6vm9uh8aq', '127.0.0.1', '1519585645', '__ci_last_regenerate|i:1519585645;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hliaqt6gvi26qdivr65thlnljep0svit', '127.0.0.1', '1519585952', '__ci_last_regenerate|i:1519585952;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o77na4333447b3iadd2de9r8bqp5tmf3', '127.0.0.1', '1519586322', '__ci_last_regenerate|i:1519586322;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dhvdtjucm91j6t680bcos4qph2vs9ug5', '127.0.0.1', '1519586687', '__ci_last_regenerate|i:1519586687;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eh6bqdusjbq9h79pun7409rjftalhprv', '127.0.0.1', '1519587008', '__ci_last_regenerate|i:1519587008;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nn7q08rog1sq8sp9m0mvjc4g9s2j7qvb', '127.0.0.1', '1519587428', '__ci_last_regenerate|i:1519587428;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7gprjcnce5vrhnvborett9endjpu013t', '127.0.0.1', '1519587924', '__ci_last_regenerate|i:1519587924;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:27:\"Intents added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68u17ocls6ss5o6a89cq1p8sghhm1s3f', '127.0.0.1', '1519588741', '__ci_last_regenerate|i:1519588741;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u00r6a8gjr4j2ud79no5513qok2cjs9p', '127.0.0.1', '1519589087', '__ci_last_regenerate|i:1519589087;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tqe196876cn4ua0ntn5m9rfk6opkl9tf', '127.0.0.1', '1519589410', '__ci_last_regenerate|i:1519589410;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3jg9m5i1s5t46arujdnvqhao034m8n8u', '127.0.0.1', '1519589852', '__ci_last_regenerate|i:1519589852;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2fhc07jdor7cl7poqho1pg3il00ia0f', '127.0.0.1', '1519590168', '__ci_last_regenerate|i:1519590168;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70r2t8m2dt3u8jvop3v02c8po5naomjh', '127.0.0.1', '1519594400', '__ci_last_regenerate|i:1519594400;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2j60qh53l9tak0jtfi1kr43diq04nufa', '127.0.0.1', '1519594733', '__ci_last_regenerate|i:1519594733;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24fpuv6vh1nskqcht2c09rrrjp8hgfpo', '127.0.0.1', '1519595038', '__ci_last_regenerate|i:1519595038;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2eebjnmnpo9iid3jba8g2fa7raghv2cb', '127.0.0.1', '1519595760', '__ci_last_regenerate|i:1519595760;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3d3ai3870v3o75fhf6ti528hpav7s3k', '127.0.0.1', '1519596117', '__ci_last_regenerate|i:1519596117;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";message-success|s:27:\"Intents added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s19a2ueumkjllbv6ct6s0pveqphshqgk', '127.0.0.1', '1519596773', '__ci_last_regenerate|i:1519596773;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f415qtm9pfdnmbak2bocclf0u2omsr9', '127.0.0.1', '1519597093', '__ci_last_regenerate|i:1519597093;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uha6op1qbbhace9tj4oj063a2q301fli', '127.0.0.1', '1519597443', '__ci_last_regenerate|i:1519597443;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0q59clld3de7v5snuar4fhmqtqebqjll', '127.0.0.1', '1519597762', '__ci_last_regenerate|i:1519597762;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('es17cdmig7ksbs3ts069kj77ijcbhuou', '127.0.0.1', '1519598262', '__ci_last_regenerate|i:1519598262;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('urku7gtoio2joe9a7ipkedpudik71jfe', '127.0.0.1', '1519599329', '__ci_last_regenerate|i:1519599329;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oe2u0did52prkhf4f6mqs9duk441l6kk', '127.0.0.1', '1519599649', '__ci_last_regenerate|i:1519599649;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53tu4lnss2pi01suu504aa44pn10l7as', '127.0.0.1', '1519601947', '__ci_last_regenerate|i:1519601947;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d9oulfrmka6tah5kmtnhbjjqb7us55a', '127.0.0.1', '1519602442', '__ci_last_regenerate|i:1519602442;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6871e772v17r3irdjf0sj5vu3m4lpn0g', '127.0.0.1', '1519602839', '__ci_last_regenerate|i:1519602839;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uf0okjjol88mg91a37did79ggf0rdmot', '127.0.0.1', '1519603182', '__ci_last_regenerate|i:1519603182;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sjn48niaafjfr4uu7p6mvfisre3f2205', '127.0.0.1', '1519603652', '__ci_last_regenerate|i:1519603652;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95kf4pmbtdcq7nobbf1mlmmcp8hccfl7', '127.0.0.1', '1519604034', '__ci_last_regenerate|i:1519604034;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i33260s74tqmsrv8s364ci6unn8qo0it', '127.0.0.1', '1519604808', '__ci_last_regenerate|i:1519604808;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p8fmfdtbn7luedgmj5jdjvov87mmimh1', '127.0.0.1', '1519605123', '__ci_last_regenerate|i:1519605123;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b26qrde36nd7ivf1n4eltt9ivpel1p8e', '127.0.0.1', '1519605466', '__ci_last_regenerate|i:1519605466;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qg9dgqmjujplnh50ek2ok0rc89lf9eh0', '127.0.0.1', '1519605828', '__ci_last_regenerate|i:1519605828;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2kdsihq0ibn673p5cufncj4iusgqg8rh', '127.0.0.1', '1519606134', '__ci_last_regenerate|i:1519606134;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8eldmifiqmcegc2vk5gl1vmnkjia3i7n', '127.0.0.1', '1519606511', '__ci_last_regenerate|i:1519606511;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cj139dlnollshneh8tjdmdg8jpvvd4sk', '127.0.0.1', '1519606818', '__ci_last_regenerate|i:1519606818;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('061621kpp66h4qq9hski2o8qpgpv32cr', '127.0.0.1', '1519607121', '__ci_last_regenerate|i:1519607121;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6r1eu392qcaijchu9lsbipeolvr886sc', '127.0.0.1', '1519607730', '__ci_last_regenerate|i:1519607730;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3vrkrr8bn8pn29kd6qdgnkson7jciavm', '127.0.0.1', '1519608040', '__ci_last_regenerate|i:1519608040;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5sed19l5otifjo16m2nin3qoqfl1itg0', '127.0.0.1', '1519608351', '__ci_last_regenerate|i:1519608351;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0lrs3jam43vk1bfqq4pa7v6a52smbpt4', '127.0.0.1', '1519608904', '__ci_last_regenerate|i:1519608904;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kpfjk184mafjd85b3kgu8e02vef5npmu', '127.0.0.1', '1519609238', '__ci_last_regenerate|i:1519609238;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r6tgda5anhsf7tem60r86np7pt6i3u9k', '127.0.0.1', '1519609549', '__ci_last_regenerate|i:1519609549;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dcko9bvn1fubsse6m9skcj8hmbkrnqqf', '127.0.0.1', '1519613815', '__ci_last_regenerate|i:1519613815;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0tefnpduidudg6lr8ntb3jff4mbssel3', '127.0.0.1', '1519614302', '__ci_last_regenerate|i:1519614302;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8k1f1pognputbi92fbro30nctak75mp', '127.0.0.1', '1519614659', '__ci_last_regenerate|i:1519614659;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cchku1h7c542irq4d355e6qgurps09pn', '127.0.0.1', '1519615085', '__ci_last_regenerate|i:1519615085;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4fch8f7f2dcdfka9mrper4ags23lbvgb', '127.0.0.1', '1519615454', '__ci_last_regenerate|i:1519615454;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7sqdkvn1u826u8kkfpqv8d4bnojs1no8', '127.0.0.1', '1519615781', '__ci_last_regenerate|i:1519615781;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gld49rqdqlt1srf861ag224cp5asnbe8', '127.0.0.1', '1519616082', '__ci_last_regenerate|i:1519616082;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('npi7ukq5cl3eovushph89f2p3nvjm133', '127.0.0.1', '1519616539', '__ci_last_regenerate|i:1519616539;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20dhffev0s3gb1i0bl232luui2fh677j', '127.0.0.1', '1519616848', '__ci_last_regenerate|i:1519616848;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iu6iu85d4ce5u4hq7jc7d6ja6089js84', '127.0.0.1', '1519617162', '__ci_last_regenerate|i:1519617162;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2gidpuh5viivf5l7sejjvjaeubssg47a', '127.0.0.1', '1519618310', '__ci_last_regenerate|i:1519618310;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ah7vnrsr4p2gedn7g15iom790dg0vsq1', '127.0.0.1', '1519618734', '__ci_last_regenerate|i:1519618734;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s0cg4imh02bj5n6p9mfs3i40ofsnm960', '127.0.0.1', '1519619192', '__ci_last_regenerate|i:1519619192;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f1t3feboms45cgo7inococpkm70asj8', '127.0.0.1', '1519619594', '__ci_last_regenerate|i:1519619594;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uk3neg8etb262jq8psmdahd76p52gs1a', '127.0.0.1', '1519619902', '__ci_last_regenerate|i:1519619902;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fl44fbmn1eauo1k1ccgs2gjncjkq8cq3', '127.0.0.1', '1519620624', '__ci_last_regenerate|i:1519620624;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0ba2ph91f1hhvgj3siirlrgaek221bg', '127.0.0.1', '1519620926', '__ci_last_regenerate|i:1519620926;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ai4qt8moo3p9654ms80es7h1gcavcetb', '127.0.0.1', '1519621412', '__ci_last_regenerate|i:1519621412;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e59n8qf83omj8h3rbklaram9el7kmtg', '127.0.0.1', '1519621773', '__ci_last_regenerate|i:1519621773;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ia04mc25ggbsd9cvjh2r1oc7m5994ipl', '127.0.0.1', '1519622100', '__ci_last_regenerate|i:1519622100;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t8psjk26pgv9kkn3o606hb1gu89ug4lo', '127.0.0.1', '1519622552', '__ci_last_regenerate|i:1519622552;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q18gogb2d9c4kp2tf3m89s6cn1hnue3k', '127.0.0.1', '1519622924', '__ci_last_regenerate|i:1519622924;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d80c4a3lk0f33rdlkqokacvckrbs77ob', '127.0.0.1', '1519623258', '__ci_last_regenerate|i:1519623258;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ggfe7m99q3at0rs904ak2udbgomko5ir', '127.0.0.1', '1519623763', '__ci_last_regenerate|i:1519623763;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gk5nbh59s7m9o5hlfabq3n6jbdoqmusp', '127.0.0.1', '1519624233', '__ci_last_regenerate|i:1519624233;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('std8bvdpgen1leoffcu6gj87o1h2nbq1', '127.0.0.1', '1519624635', '__ci_last_regenerate|i:1519624635;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cm87j3g2mf9s2tfjilcav5vgjubka83r', '127.0.0.1', '1519625001', '__ci_last_regenerate|i:1519625001;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('glqd33p27srgph7cb5gm5lueubic85uv', '127.0.0.1', '1519625394', '__ci_last_regenerate|i:1519625394;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75u0sm9aflc1mq5mpa9ivv4drj4ilg9f', '127.0.0.1', '1519625697', '__ci_last_regenerate|i:1519625697;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83jj5qmnb654krj8arsili36n1a82352', '127.0.0.1', '1519626105', '__ci_last_regenerate|i:1519626105;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hetsifhojd16kkhumemtu8o0vi789mj3', '127.0.0.1', '1519626442', '__ci_last_regenerate|i:1519626442;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hs4ne6btlfpu2565l0rjkud682bcs6iq', '127.0.0.1', '1519626926', '__ci_last_regenerate|i:1519626926;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pdm674odd9f00heu41mp91bv01dtska0', '127.0.0.1', '1519627272', '__ci_last_regenerate|i:1519627272;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n740aa71sd81ug9s0jppml0sgj6u0cmh', '127.0.0.1', '1519627580', '__ci_last_regenerate|i:1519627580;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s1ojci4uh37j3p4ju4tc0jsltn62kuhr', '127.0.0.1', '1519628374', '__ci_last_regenerate|i:1519628374;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90153ht2bkhj73ip5g90lle9lop73t1q', '127.0.0.1', '1519628694', '__ci_last_regenerate|i:1519628694;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nvch55365tf8hg7j9m98v7u5pemcl47e', '127.0.0.1', '1519629148', '__ci_last_regenerate|i:1519629148;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('saqe63i7vvb3e7ad10gdbtp5aetg33g4', '127.0.0.1', '1519629456', '__ci_last_regenerate|i:1519629456;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ljvqpekh2id2j5tr4jm1us8aik242gbe', '127.0.0.1', '1519629848', '__ci_last_regenerate|i:1519629848;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bu8gmqo1biqas2veul11dsj9732tdk1', '127.0.0.1', '1519630173', '__ci_last_regenerate|i:1519630173;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6rpql0l39p7uu9r1gdih1jp4kvbddg3', '127.0.0.1', '1519630627', '__ci_last_regenerate|i:1519630627;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jpmff64g83gmhadc50r0hlh9e3a4ucrc', '127.0.0.1', '1519630957', '__ci_last_regenerate|i:1519630957;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('scfaeq7f2sdkojqun5dnttms4fi0oglr', '127.0.0.1', '1519631495', '__ci_last_regenerate|i:1519631495;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o522k82u9uiitf9hplolt8jskveml7kl', '127.0.0.1', '1519631796', '__ci_last_regenerate|i:1519631796;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v2ib2pk70pqq4isrtb7j2teo98b5momn', '127.0.0.1', '1519632448', '__ci_last_regenerate|i:1519632448;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('509sb2ruj59j0a1e516lenaphrd5fq2b', '127.0.0.1', '1519632897', '__ci_last_regenerate|i:1519632897;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('odu7174rssf4pgjemijusesqkuosail6', '127.0.0.1', '1519633292', '__ci_last_regenerate|i:1519633292;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m01q2m2gpll9f9m3h5nfjo0r71lajdcu', '127.0.0.1', '1519633663', '__ci_last_regenerate|i:1519633663;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rpl1rs29t56kp2tc9dk61beua08mb590', '127.0.0.1', '1519634004', '__ci_last_regenerate|i:1519634004;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ujlrgbijiqtetjgfh7vbcb8idne97efm', '127.0.0.1', '1519634330', '__ci_last_regenerate|i:1519634330;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tqd33jtfm5vfcm0kscuu3ba5ckjnhrir', '127.0.0.1', '1519634631', '__ci_last_regenerate|i:1519634631;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"new\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6si731c6ui5id16v28hans8mnhj80vkb', '127.0.0.1', '1519634937', '__ci_last_regenerate|i:1519634937;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qn7e7vi6bartb4vg659u5kjefva25521', '127.0.0.1', '1519635452', '__ci_last_regenerate|i:1519635452;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('prqikorkfc2cdb5cmin3nch0isk1030f', '127.0.0.1', '1519635810', '__ci_last_regenerate|i:1519635810;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t6o1o9bpmp7f3i3vfpqp87ekk4068em8', '127.0.0.1', '1519636137', '__ci_last_regenerate|i:1519636137;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db5hujbdcuelob80300sta7t04ldpnmq', '127.0.0.1', '1519636504', '__ci_last_regenerate|i:1519636504;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5p2q93l5gdv04esk6k1eeetg7iaivq6b', '127.0.0.1', '1519636848', '__ci_last_regenerate|i:1519636848;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('migujl5ljah1kad7jrh0b01k441bh4hr', '127.0.0.1', '1519637704', '__ci_last_regenerate|i:1519637704;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6tvvdglml0avb2sbg7rso3ccrioo3d3i', '127.0.0.1', '1519638026', '__ci_last_regenerate|i:1519638026;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('to01hn2g9souvcqo2tcnr8q5biimnp7f', '127.0.0.1', '1519638672', '__ci_last_regenerate|i:1519638672;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l852j1pf0pr3138iaq6crq71ndgtbqef', '127.0.0.1', '1519639003', '__ci_last_regenerate|i:1519639003;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aq160qk25ur7he91981hges8f7pnooue', '127.0.0.1', '1519642656', '__ci_last_regenerate|i:1519642656;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aboef87asmscd0uhsvpkjkm6onsn1sop', '127.0.0.1', '1519642980', '__ci_last_regenerate|i:1519642980;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k11hksiu69qlo8ss9crj61i3scor4ch9', '127.0.0.1', '1519643353', '__ci_last_regenerate|i:1519643353;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ga735l5pumh69kn4je8eloa2nu6i81vi', '127.0.0.1', '1519643660', '__ci_last_regenerate|i:1519643660;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q53lcdcmm8gi65g8d8ed293tk32g53lj', '127.0.0.1', '1519644593', '__ci_last_regenerate|i:1519644593;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3i27o9torull50ni1jketk13ts2tuuh', '127.0.0.1', '1519645023', '__ci_last_regenerate|i:1519645023;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o5sr8u2igohh64hm9vfnhqr7eo78pmth', '127.0.0.1', '1519645422', '__ci_last_regenerate|i:1519645422;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u8d5aieo92a8lof2qsi3am92sbkgqe1v', '127.0.0.1', '1519646228', '__ci_last_regenerate|i:1519646228;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o35mdqpahvshdt1lna7jdckvtef1as2f', '127.0.0.1', '1519646637', '__ci_last_regenerate|i:1519646637;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1onb2he5mtm6gv7t164d7tc3asl7ccua', '127.0.0.1', '1519647049', '__ci_last_regenerate|i:1519647049;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tcbuboc3fqblmr7japg48t6obohh712b', '127.0.0.1', '1519647883', '__ci_last_regenerate|i:1519647883;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lit6kv4eoqnba9va4h1nmme819cq27fk', '127.0.0.1', '1519650828', '__ci_last_regenerate|i:1519650828;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('663igv2jki4rct07oih2ligl6rv60f9s', '127.0.0.1', '1519673527', '__ci_last_regenerate|i:1519673527;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v0unsn9ihn72q3i8l9de06ht9db8vf9m', '127.0.0.1', '1519674090', '__ci_last_regenerate|i:1519674090;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kdh3k87scc77cl43i8r3d4bgv51ds006', '127.0.0.1', '1519674459', '__ci_last_regenerate|i:1519674459;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6ej60ifb69tjpa3kef3ahhrp4r79t3r', '127.0.0.1', '1519675213', '__ci_last_regenerate|i:1519675213;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bi9ml69prf8qksb5sgvhmland6vamhrk', '127.0.0.1', '1519675915', '__ci_last_regenerate|i:1519675915;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sqrtd8s8isl9pn9pfbtlu9kld9oncqan', '127.0.0.1', '1519676315', '__ci_last_regenerate|i:1519676315;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjr56mkafl1nr74c7gprvkia1bvp1acm', '127.0.0.1', '1519676647', '__ci_last_regenerate|i:1519676647;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ki9ajouims1sg485s67sl1jlv7g44l2', '127.0.0.1', '1519676995', '__ci_last_regenerate|i:1519676995;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9vkcpmm95ehdk3025nbf37e1ifrh8lsp', '127.0.0.1', '1519677306', '__ci_last_regenerate|i:1519677306;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49i18ec7n5iqmvejftfqfovclb1vkdh6', '127.0.0.1', '1519677933', '__ci_last_regenerate|i:1519677933;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9lffo9vffrpr5r5k4v2kgjtsn17bk1r', '127.0.0.1', '1519678738', '__ci_last_regenerate|i:1519678738;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k94jvitg5kt6tn4rfbdl0n66gai3ut8o', '127.0.0.1', '1519678783', '__ci_last_regenerate|i:1519678783;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('td42u92svei1lg1ijpl9dedqfbm2j6oi', '127.0.0.1', '1519679433', '__ci_last_regenerate|i:1519679433;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f53oe545ss99f59ehlu3itqkfbp5f30e', '127.0.0.1', '1519679215', '__ci_last_regenerate|i:1519679215;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('upfr1go3di898umqb76d1a68jj4brtaj', '127.0.0.1', '1519679846', '__ci_last_regenerate|i:1519679846;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5oi9efmtutrdj6v6clfqureoohgci561', '127.0.0.1', '1519679834', '__ci_last_regenerate|i:1519679834;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-success|s:16:\"Settings Updated\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1upr6beukfim2824gk45dfi85fsfl4q7', '127.0.0.1', '1519684401', '__ci_last_regenerate|i:1519684401;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-success|s:16:\"Settings Updated\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3jafa3m3hhi5nkdib6q59vsf9lr31qm6', '127.0.0.1', '1519680280', '__ci_last_regenerate|i:1519680280;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dqr2ig4g3h4g940h2bn8lc0f865lj9id', '127.0.0.1', '1519680699', '__ci_last_regenerate|i:1519680699;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8p75855iqi58evl0licgqviighh4og92', '127.0.0.1', '1519681192', '__ci_last_regenerate|i:1519681192;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('snfrt323nsni31ubmbdebfj1tph8ml5v', '127.0.0.1', '1519681707', '__ci_last_regenerate|i:1519681707;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkb9loo1qhtgjqif4tgif0ic049m8qb0', '127.0.0.1', '1519682581', '__ci_last_regenerate|i:1519682581;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lm48vaqrplv890o9j50lt7a3mmf5ohlg', '127.0.0.1', '1519682932', '__ci_last_regenerate|i:1519682932;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f9nt8c9knvbbnhh6h3brig9nl1b06g8', '127.0.0.1', '1519683236', '__ci_last_regenerate|i:1519683236;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ggm26tv30b81anaphsf2gvnhbalk72c9', '127.0.0.1', '1519683575', '__ci_last_regenerate|i:1519683575;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('te3v3uios6h8egn779l5b6omn7sph2br', '127.0.0.1', '1519684303', '__ci_last_regenerate|i:1519684303;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('je1569llmv84b49fg4rsf89v6gsiirhn', '127.0.0.1', '1519688842', '__ci_last_regenerate|i:1519688842;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9sr3h1r92ggjl3g707qb4i9beb6pmbi2', '127.0.0.1', '1519684764', '__ci_last_regenerate|i:1519684764;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4jtkp4oubr4u5nkcq27rebc0s9pjr3gt', '127.0.0.1', '1519685067', '__ci_last_regenerate|i:1519685067;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3q2d5f3tsm8iglugm6gqb7lbc5qe2plr', '127.0.0.1', '1519685405', '__ci_last_regenerate|i:1519685405;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8q2807nvjkijnsddhsd0g6pn09lbf1kq', '127.0.0.1', '1519685750', '__ci_last_regenerate|i:1519685750;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v2l7kbqvrsev97o10qh9us2hoh6j291m', '127.0.0.1', '1519686174', '__ci_last_regenerate|i:1519686174;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('maeokhn6lfrv23v5uqd5nad7uvn5vi3b', '127.0.0.1', '1519686515', '__ci_last_regenerate|i:1519686515;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bt0ovqctoj9gtn66fh67mmetlp8h63ck', '127.0.0.1', '1519686844', '__ci_last_regenerate|i:1519686844;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pgl0traoe0405mjv91l14fd3t4akq17e', '127.0.0.1', '1519687292', '__ci_last_regenerate|i:1519687292;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmcp7rr5ffvvf05it471n9s5tint35eb', '127.0.0.1', '1519687641', '__ci_last_regenerate|i:1519687641;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9vl95ilqs14ieneatucse9mknuuujuo7', '127.0.0.1', '1519688038', '__ci_last_regenerate|i:1519688038;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2cq3v26ft5mlb4k6np8qaa1s166mc23k', '127.0.0.1', '1519688377', '__ci_last_regenerate|i:1519688377;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32q0v9r403tgl0rhr362tn0edpt2m3uj', '127.0.0.1', '1519688810', '__ci_last_regenerate|i:1519688810;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p1bbci8559np70g7njv2u8o6p7jgghj5', '127.0.0.1', '1519689193', '__ci_last_regenerate|i:1519689193;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bfu30pv278fe2tbk89sb7c51oqqkfma7', '127.0.0.1', '1519689628', '__ci_last_regenerate|i:1519689628;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kag4d6dhc3lj7ej2r87t2v3qrp7vst6s', '127.0.0.1', '1519689526', '__ci_last_regenerate|i:1519689526;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfgq0ijcs2v5ltp7m2inck4ktphuv7up', '127.0.0.1', '1519689939', '__ci_last_regenerate|i:1519689939;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ummp0ndkrdeqqbecbgtbo6a45vvg694', '127.0.0.1', '1519691908', '__ci_last_regenerate|i:1519691908;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lge0ogbg800lg42tevvssvagmbcvp7ka', '127.0.0.1', '1519690244', '__ci_last_regenerate|i:1519690244;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uh0m254r5u9eopqsomsv2ikg0ikb9a0l', '127.0.0.1', '1519690594', '__ci_last_regenerate|i:1519690594;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('evub3etlre5uuodvfjq9skumlet46eku', '127.0.0.1', '1519690930', '__ci_last_regenerate|i:1519690930;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o38riueqd57977983ktirv2bi51r4edr', '127.0.0.1', '1519691326', '__ci_last_regenerate|i:1519691326;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04ik4c0k5bfon7mvr6tdk49m03k9nefc', '127.0.0.1', '1519691769', '__ci_last_regenerate|i:1519691769;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dh4lompedl8gheqlhe3re1oboi7ua5c5', '127.0.0.1', '1519691811', '__ci_last_regenerate|i:1519691769;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97bt561aqc6a0d0e6qb7d4g98lp40ecp', '127.0.0.1', '1519691909', '__ci_last_regenerate|i:1519691909;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n9efjvqrp640ua8gf7nklojia783hkn1', '127.0.0.1', '1519721446', '__ci_last_regenerate|i:1519721446;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3hlviib4b10pkqsscge2sdn8tbm7enc', '127.0.0.1', '1519721790', '__ci_last_regenerate|i:1519721790;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h7c3oc3aen18ll60kkog9g7b935jau09', '127.0.0.1', '1519722143', '__ci_last_regenerate|i:1519722143;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s9cg3euou9ngr6a32jben9cospunhr84', '127.0.0.1', '1519722555', '__ci_last_regenerate|i:1519722555;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g1e3po9h7lld3goihk1dm8840t59vp8s', '127.0.0.1', '1519722955', '__ci_last_regenerate|i:1519722955;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o29k049skvvmur9nnu78lisr9obb5rmp', '127.0.0.1', '1519723260', '__ci_last_regenerate|i:1519723260;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hc71hf20vjfnkjhfv599d82pnum97qtq', '127.0.0.1', '1519723806', '__ci_last_regenerate|i:1519723806;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqdl4inof3d714gpgg6ug25r5b4fnv7j', '127.0.0.1', '1519724123', '__ci_last_regenerate|i:1519724123;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3vjaihito95tk3hg751k6g7cmek2fuu', '127.0.0.1', '1519724728', '__ci_last_regenerate|i:1519724728;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o0krorosnt2khi6blcss4vc2fu4ts231', '127.0.0.1', '1519729735', '__ci_last_regenerate|i:1519729735;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dt2em2812kmttoqivg3rj4006u33qrpf', '127.0.0.1', '1519730656', '__ci_last_regenerate|i:1519730656;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r26hr160q4b51uhoi7tkrv8rnaitsde6', '127.0.0.1', '1519731194', '__ci_last_regenerate|i:1519731194;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bim2i2irsnimbhiq970lv0070amig3c3', '127.0.0.1', '1519731174', '__ci_last_regenerate|i:1519731174;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sbs57l09q1jc7iu810526gjemff9bg63', '127.0.0.1', '1519731482', '__ci_last_regenerate|i:1519731482;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86g4vjqj0j0qtbomjkj1dkiaa3842l7i', '127.0.0.1', '1519731519', '__ci_last_regenerate|i:1519731519;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('keqdnrngan0rf61djdmklqvh0pgn6hfq', '127.0.0.1', '1519731804', '__ci_last_regenerate|i:1519731804;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('livrdbvajk7e21vg1f1seefppm6acpf4', '127.0.0.1', '1519732789', '__ci_last_regenerate|i:1519732789;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9q2frvoms950k7bu75gjd7fc00n4tvuc', '127.0.0.1', '1519732356', '__ci_last_regenerate|i:1519732356;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vnapg8oqu4o07clghbgsaj841u4rsgit', '127.0.0.1', '1519732680', '__ci_last_regenerate|i:1519732680;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ekmk17sbl5vl5hepplcqg0cfrirptfq', '127.0.0.1', '1519732983', '__ci_last_regenerate|i:1519732983;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3mb1k052iobahce28r8651dfltgejt6i', '127.0.0.1', '1519735616', '__ci_last_regenerate|i:1519735616;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u79nm5jc141lppj8he959i21vjmorh4d', '127.0.0.1', '1519733352', '__ci_last_regenerate|i:1519733352;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rroams4mrq45rmr6rb7secccjh6fq2u', '127.0.0.1', '1519733675', '__ci_last_regenerate|i:1519733675;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('plvg9uo997grisikg8j6svl2mtcohcpm', '127.0.0.1', '1519734099', '__ci_last_regenerate|i:1519734099;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2ch1v2l641i87gnhp0esk221rhntpqa', '127.0.0.1', '1519734738', '__ci_last_regenerate|i:1519734738;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08d31nhk4t25dn1e7vufu8h6vpt0aces', '127.0.0.1', '1519735161', '__ci_last_regenerate|i:1519735161;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eu98uilbd8rnkll7lb91rkjinlthtfb9', '127.0.0.1', '1519735603', '__ci_last_regenerate|i:1519735603;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4425ilodi43ssghrjkt77fi67h9aao7', '127.0.0.1', '1519736592', '__ci_last_regenerate|i:1519736592;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4p0dvu3acvjpv86lo0klh9kb2e8663s', '127.0.0.1', '1519736581', '__ci_last_regenerate|i:1519736581;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('54p60pjkpj2lkfoa0mr0eq038mlcb64c', '127.0.0.1', '1519752269', '__ci_last_regenerate|i:1519752269;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ara74r37vdmtkvj0cobsgqiua339jvnf', '127.0.0.1', '1519736961', '__ci_last_regenerate|i:1519736961;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aquo5qr5lbu3g2uo2dir18i8grg3jota', '127.0.0.1', '1519738914', '__ci_last_regenerate|i:1519738914;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9485srlgtmvaj1b8efffiun9l8hbcb7', '127.0.0.1', '1519752225', '__ci_last_regenerate|i:1519752225;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3mhrtvk3sfughh23sa6jqgdh7mff6eo', '127.0.0.1', '1519753104', '__ci_last_regenerate|i:1519753104;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6a7jf5ob2tlpkhj4s2n6ac6thkkf71p', '127.0.0.1', '1519754917', '__ci_last_regenerate|i:1519754917;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2gons6q6pop5u1lv14fcclnps5fsh9j', '127.0.0.1', '1519753595', '__ci_last_regenerate|i:1519753595;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9l8gs7hf3ppmaumoujmmopapava1ullk', '127.0.0.1', '1519753906', '__ci_last_regenerate|i:1519753906;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bjfbvth0s5r3824kc27ivkkb7c4s7dg1', '127.0.0.1', '1519754213', '__ci_last_regenerate|i:1519754213;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6lshvem0dhl35ce5lijjod4n11rdksrd', '127.0.0.1', '1519754748', '__ci_last_regenerate|i:1519754748;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mrmato1qv55009pu09fa4nl0cri7t3lt', '127.0.0.1', '1519755068', '__ci_last_regenerate|i:1519755068;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57fcatk6lkfedpva8sabfhkje63vuv0v', '127.0.0.1', '1519760021', '__ci_last_regenerate|i:1519760021;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pcq4eg3erbhm2pit0vdcek43mr1eoq01', '127.0.0.1', '1519755390', '__ci_last_regenerate|i:1519755390;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fumv2njt54cn0anbd4dceub1q3o71rb4', '127.0.0.1', '1519755758', '__ci_last_regenerate|i:1519755758;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iavjh10n3u80ji1p2iqaadc8dnoe4gd1', '127.0.0.1', '1519756101', '__ci_last_regenerate|i:1519756101;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/intent/12\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6o8vle3ko8hvravffc844vviftlmh779', '127.0.0.1', '1519756427', '__ci_last_regenerate|i:1519756427;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('822bdl0gv1itid83g9lpa6k9dc0d5v89', '127.0.0.1', '1519756756', '__ci_last_regenerate|i:1519756756;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fnvqphcee3sd66gql734sc95plf978l2', '127.0.0.1', '1519757095', '__ci_last_regenerate|i:1519757095;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qk99qodut0njhd5undtphqajcu4s0jjd', '127.0.0.1', '1519757465', '__ci_last_regenerate|i:1519757465;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t14qjjjc5ivsrgi04j1m27tqsb6ec0s5', '127.0.0.1', '1519757779', '__ci_last_regenerate|i:1519757779;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9p63mkfnk2jrc43a73pq8cqie6j9c26', '127.0.0.1', '1519758160', '__ci_last_regenerate|i:1519758160;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hmmtt30hm3s8agdqk0o0ga9bg6asd4q6', '127.0.0.1', '1519758468', '__ci_last_regenerate|i:1519758468;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0dqet4f90m8355et7qbn308r0vcempon', '127.0.0.1', '1519758873', '__ci_last_regenerate|i:1519758873;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('936inf0kldf8655e22l1024668c501gc', '127.0.0.1', '1519759177', '__ci_last_regenerate|i:1519759177;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10a3g7mui1t5uugikj7aq5gl1iii4u6f', '127.0.0.1', '1519759505', '__ci_last_regenerate|i:1519759505;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h7u0r0nqsncai87v81ji5bse8b9nbncf', '127.0.0.1', '1519759811', '__ci_last_regenerate|i:1519759811;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sufbjod1livgm5tm9cghrvbn0pgul57o', '127.0.0.1', '1519760127', '__ci_last_regenerate|i:1519760127;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";message-warning|s:11:\"agent_exist\";__ci_vars|a:1:{s:15:\"message-warning\";s:3:\"new\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed8tuq5uk8d65hlqmocrbs4p15tv2hp4', '127.0.0.1', '1519760898', '__ci_last_regenerate|i:1519760898;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('janietd4njn6lleqdc2l3f1fvnuejnop', '127.0.0.1', '1519760439', '__ci_last_regenerate|i:1519760439;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5irlbucub6k7k6ms2u0o8er00nm69uvp', '127.0.0.1', '1519760766', '__ci_last_regenerate|i:1519760766;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('skllpju12v9hspdrmftk4bmd6ohodu0u', '127.0.0.1', '1519761155', '__ci_last_regenerate|i:1519761155;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pt1filbfhdmpgcofj4aftn0ad9pv7ij2', '127.0.0.1', '1519761884', '__ci_last_regenerate|i:1519761884;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25qadn83v6fa3utpqh595p03si4brlnr', '127.0.0.1', '1519761490', '__ci_last_regenerate|i:1519761490;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0uj1fgb9bq0g3dgo0neoh3ebpk9oukf3', '127.0.0.1', '1519761966', '__ci_last_regenerate|i:1519761966;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gv9r2pt7422qvc182kbsmr75jhgeo9fh', '127.0.0.1', '1519762991', '__ci_last_regenerate|i:1519762991;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i6kti2d3hqlqh6sgv8932vh56oc1fv4f', '127.0.0.1', '1519762558', '__ci_last_regenerate|i:1519762558;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5rfk4o6jp95mfhij46a26712anud17sm', '127.0.0.1', '1519762859', '__ci_last_regenerate|i:1519762859;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4p28ivqshqe6th5a6f111rb8ae5a933g', '127.0.0.1', '1519763252', '__ci_last_regenerate|i:1519763252;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l1k46ar0o8gibpm1eir4s14lr6538g25', '127.0.0.1', '1519763645', '__ci_last_regenerate|i:1519763645;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ao34ql3iide04r8ccvbt8bmr4uaq4nrv', '127.0.0.1', '1519763654', '__ci_last_regenerate|i:1519763654;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a296tcafaq3dr00fb5r1qgnrpevhgf1c', '127.0.0.1', '1519773817', '__ci_last_regenerate|i:1519773817;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v19qj1l9d00ebtnci3rfh2b4u88q17sd', '127.0.0.1', '1519766072', '__ci_last_regenerate|i:1519766072;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ifej62tgemvk9g4csdr2ki5gctgo25oo', '127.0.0.1', '1519766374', '__ci_last_regenerate|i:1519766374;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2aoe1li9nkhjd4r57h0avdntsprj9eg1', '127.0.0.1', '1519766775', '__ci_last_regenerate|i:1519766775;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7iaops9he585atiqdl82lnh7eqolo18', '127.0.0.1', '1519767505', '__ci_last_regenerate|i:1519767505;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q91vi2jbqb1rbuavolc0tpv6lc9452oj', '127.0.0.1', '1519767935', '__ci_last_regenerate|i:1519767935;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('npljrvpv04vbeiaorcrk87q3s3v3ask8', '127.0.0.1', '1519768306', '__ci_last_regenerate|i:1519768306;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvglbp3jvpagdapnd958befk8m3bql7d', '127.0.0.1', '1519768798', '__ci_last_regenerate|i:1519768798;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nmb3896geppr1r2pmlgkqm87aslo2v6r', '127.0.0.1', '1519769137', '__ci_last_regenerate|i:1519769137;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45fmskia8v9ilapae9h8v9fv4jb7ssgr', '127.0.0.1', '1519769456', '__ci_last_regenerate|i:1519769456;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mskka4ooibblg385b3hag0q1d9gkj0ai', '127.0.0.1', '1519769784', '__ci_last_regenerate|i:1519769784;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e9626eej218qqg154irlsmo62mq2ckj3', '127.0.0.1', '1519770113', '__ci_last_regenerate|i:1519770113;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s5n0ea394n25er0tdcbou7t0n9m7lsbo', '127.0.0.1', '1519770878', '__ci_last_regenerate|i:1519770878;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b5rc2savij14uc0j2i2cm13l34g9r3r5', '127.0.0.1', '1519771407', '__ci_last_regenerate|i:1519771407;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('398b1ic8aukp9mi4ieak57fa8mmg0kg4', '127.0.0.1', '1519771726', '__ci_last_regenerate|i:1519771726;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('74qug5l7ruc05f97k7mqj4ila8eiocsf', '127.0.0.1', '1519772047', '__ci_last_regenerate|i:1519772047;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5dt152s2oh7ul1eojt3aae01u77rjqd5', '127.0.0.1', '1519772365', '__ci_last_regenerate|i:1519772365;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e43191fpjfripuqckf30cb95o0sshmj5', '127.0.0.1', '1519772901', '__ci_last_regenerate|i:1519772901;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lvh1sfvm1pra5jj20fbkb2mjp0k72j8l', '127.0.0.1', '1519773251', '__ci_last_regenerate|i:1519773251;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3ski5nl2v9gpv6jflffdeao0hva1t3b', '127.0.0.1', '1519773566', '__ci_last_regenerate|i:1519773566;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;red_url|s:23:\"admin/intents/delete/22\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ml54mhfds276ooio2da18htejdas9vi', '127.0.0.1', '1519798790', '__ci_last_regenerate|i:1519798790;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ha7tjf390mfd065h2rnc24ptirlgt5ph', '127.0.0.1', '1519798760', '__ci_last_regenerate|i:1519798760;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('brb8ipe8htc29fnmih4e7b9bfmkije78', '127.0.0.1', '1519804319', '__ci_last_regenerate|i:1519804319;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17lqkivjh3jm78q6oikd11s651mqhc6d', '127.0.0.1', '1519799179', '__ci_last_regenerate|i:1519799179;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fgqfn4bke324mr1cffo9938cis9014k3', '127.0.0.1', '1519799496', '__ci_last_regenerate|i:1519799496;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5kq06acnjeirjc1shphiglnp7o5gjtn', '127.0.0.1', '1519799837', '__ci_last_regenerate|i:1519799837;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o1nhodl57s1f08kc3ppsc310mq7e4tb7', '127.0.0.1', '1519800160', '__ci_last_regenerate|i:1519800160;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vuhcj6bbbjo1golp58afhugv58jcb6q8', '127.0.0.1', '1519800508', '__ci_last_regenerate|i:1519800508;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f5eqvguq4dq19t02pk0j4kvf824guf5c', '127.0.0.1', '1519800812', '__ci_last_regenerate|i:1519800812;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kverkbuqjsi8uhto2dokegl740mjk66s', '127.0.0.1', '1519801167', '__ci_last_regenerate|i:1519801167;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1khq02ablpndcbc836akasmabfh9e0al', '127.0.0.1', '1519801634', '__ci_last_regenerate|i:1519801634;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5n26tgcu1hbcjhuenekvccjh8m7v7v0l', '127.0.0.1', '1519801953', '__ci_last_regenerate|i:1519801953;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ahts12hcr5jont4r1n5r44e6kro2sog', '127.0.0.1', '1519802299', '__ci_last_regenerate|i:1519802299;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31l8jutvr270ikf24pha01vv8530t2tl', '127.0.0.1', '1519802673', '__ci_last_regenerate|i:1519802673;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ilmv9vi9a5348pi49nec3v66913q7c6e', '127.0.0.1', '1519802999', '__ci_last_regenerate|i:1519802999;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f8eo7md6kptjifl9ck1ou7e9aivcgc2s', '127.0.0.1', '1519803337', '__ci_last_regenerate|i:1519803337;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4dgljl0b1cmoevr34rqj523m4j6iivto', '127.0.0.1', '1519804314', '__ci_last_regenerate|i:1519804314;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70c9ejt9er0rm826t24uamli7aahf266', '127.0.0.1', '1519804879', '__ci_last_regenerate|i:1519804879;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e16b5srchib3jjp5loibdldm90oln8ec', '127.0.0.1', '1519810389', '__ci_last_regenerate|i:1519810389;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vn48hj5dgggbcbhm6lq3j7tbvpevscqm', '127.0.0.1', '1519805580', '__ci_last_regenerate|i:1519805580;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jr4vujdid9t4m5e1lbktjh6luai4dtr0', '127.0.0.1', '1519806005', '__ci_last_regenerate|i:1519806005;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('abmbn7n4liq27kpldtgc9bmqrv3bcmj8', '127.0.0.1', '1519806346', '__ci_last_regenerate|i:1519806346;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9lh69t41njrr65el7u3e6ge7kb83g70a', '127.0.0.1', '1519806972', '__ci_last_regenerate|i:1519806972;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2o1dsqe8nunudn71u40a99gr6mokfjs7', '127.0.0.1', '1519806741', '__ci_last_regenerate|i:1519806741;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9140r74dlfue4rer77ptccc5e1pogr71', '127.0.0.1', '1519806745', '__ci_last_regenerate|i:1519806745;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5m2p9rqdrbhs6vu00oe030ovuptegbdp', '127.0.0.1', '1519807471', '__ci_last_regenerate|i:1519807471;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e9b2agprsfk1uvdbvmf2s6qtp0kvdr2u', '127.0.0.1', '1519807400', '__ci_last_regenerate|i:1519807400;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('orc2qhs564q2mr6q1sfa4cfsupl1m54d', '127.0.0.1', '1519807854', '__ci_last_regenerate|i:1519807854;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('917tmutn3383v2og58d9p0h6opbsp4oh', '127.0.0.1', '1519807597', '__ci_last_regenerate|i:1519807597;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hip9uotbkgv973kip151cn6ie1d6ss56', '127.0.0.1', '1519807601', '__ci_last_regenerate|i:1519807601;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rib9e0bk94gi03geis5s81a8b7n1qhnu', '127.0.0.1', '1519807607', '__ci_last_regenerate|i:1519807607;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5so8jldp8g1sb11kup06dt2gii1usv90', '127.0.0.1', '1519807675', '__ci_last_regenerate|i:1519807675;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g1btu4ohrsb3vtfenfnvhf1c6djgpkdo', '127.0.0.1', '1519807720', '__ci_last_regenerate|i:1519807720;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rgchnmp69qur182099merf41ouunlkoh', '127.0.0.1', '1519807775', '__ci_last_regenerate|i:1519807775;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ihpep4ah5nqirm6p8r0a50e05um5aaf9', '127.0.0.1', '1519807778', '__ci_last_regenerate|i:1519807778;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eda76no71tnjattf5a723jo6kgjf9bib', '127.0.0.1', '1519807781', '__ci_last_regenerate|i:1519807781;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35i96g5rm3tgquvi3fpm92ufpe4jur6d', '127.0.0.1', '1519808161', '__ci_last_regenerate|i:1519808161;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mmevq7vefki73djsfrrg8ee59um0nr0r', '127.0.0.1', '1519807859', '__ci_last_regenerate|i:1519807859;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v1t9i7595a28f8je5f51tohn2sjk8n49', '127.0.0.1', '1519807930', '__ci_last_regenerate|i:1519807930;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v3vvv4iegoi7hcshal5dcdd84k99asns', '127.0.0.1', '1519807980', '__ci_last_regenerate|i:1519807980;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nh7rdoeg9j9pmsho52qn9u762elgkeep', '127.0.0.1', '1519808111', '__ci_last_regenerate|i:1519808111;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qcs8gvmf21a0f8c1go60rltassjgchkv', '127.0.0.1', '1519808122', '__ci_last_regenerate|i:1519808122;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ui7nif3tpjm8o31lin209cshq9c4i6na', '127.0.0.1', '1519808537', '__ci_last_regenerate|i:1519808537;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pe6am9va0l9sf3hj74a2fkouqq79rpah', '127.0.0.1', '1519808165', '__ci_last_regenerate|i:1519808165;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h1l7epk9ikb61n7enmhgj9tscsju8cqp', '127.0.0.1', '1519808196', '__ci_last_regenerate|i:1519808196;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qo0278h06frh2q3298ndv8n2t6oer2jf', '127.0.0.1', '1519808308', '__ci_last_regenerate|i:1519808308;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7odcbbn8u2l4gc896dblis2iaquj8oo9', '127.0.0.1', '1519808336', '__ci_last_regenerate|i:1519808336;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fid039bc0oa0ess7dehlupu957hld6u9', '127.0.0.1', '1519808450', '__ci_last_regenerate|i:1519808450;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qivruvfq2kbchqsunal2onsiri43o74i', '127.0.0.1', '1519809005', '__ci_last_regenerate|i:1519809005;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tqdvr3ggccjk6kaqm4go5d5ba1t5tl8l', '127.0.0.1', '1519808540', '__ci_last_regenerate|i:1519808540;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('flioqefmkd5907igo4iclk4v9v8m0f89', '127.0.0.1', '1519808615', '__ci_last_regenerate|i:1519808615;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2u35qouthk80mk4dl2024l1hpim75k8l', '127.0.0.1', '1519808716', '__ci_last_regenerate|i:1519808716;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06jgv2qom4n563ftac3avhbchem5ch6j', '127.0.0.1', '1519808764', '__ci_last_regenerate|i:1519808764;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fmdftutrc1t1e304l28km1unvh15b7g6', '127.0.0.1', '1519809381', '__ci_last_regenerate|i:1519809381;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tob08qf7co7sb1b04648k9l6tdmhlpo5', '127.0.0.1', '1519809008', '__ci_last_regenerate|i:1519809008;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15rg1s5lisg5te30f74kv583sajs2rdv', '127.0.0.1', '1519809046', '__ci_last_regenerate|i:1519809046;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i9qhh9boum9tfp1vcon8v1627nlvm8lr', '127.0.0.1', '1519809071', '__ci_last_regenerate|i:1519809071;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1370qi24nklb2gvq25kgug1i1hdphpk', '127.0.0.1', '1519809738', '__ci_last_regenerate|i:1519809738;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fn19f2m9duj8d85bbgbr83nfdtf445r2', '127.0.0.1', '1519810307', '__ci_last_regenerate|i:1519810307;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obohssfjo021ed9ojfqlf68pu5l7l667', '127.0.0.1', '1519809847', '__ci_last_regenerate|i:1519809847;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6j0mfhl1lr4nk6h7hk9giiasgsd2cg6g', '127.0.0.1', '1519812865', '__ci_last_regenerate|i:1519812865;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('as377oa865t8pr175uh8b1cukoq7f3u5', '127.0.0.1', '1519810768', '__ci_last_regenerate|i:1519810768;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g6oaadgqgvs8efd50sn7ns905c7f5174', '127.0.0.1', '1519811496', '__ci_last_regenerate|i:1519811496;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p92irnjeu71frfs4f26otpecgt637g4l', '127.0.0.1', '1519813286', '__ci_last_regenerate|i:1519813286;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1scfhn4364hsl39gq7bn49nugotd44du', '127.0.0.1', '1519813281', '__ci_last_regenerate|i:1519813281;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b61c3ns40gd4ip1h0j7g9fegtf62e07m', '127.0.0.1', '1519819783', '__ci_last_regenerate|i:1519819783;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('suk97o35b3kgf284ovmjc79dgid2f17p', '127.0.0.1', '1519813785', '__ci_last_regenerate|i:1519813785;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6vj8hhh7r8fondos99svo97v7iqv5fjg', '127.0.0.1', '1519814800', '__ci_last_regenerate|i:1519814800;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4k40spqpl6fodfao3chqtgbd47f8embn', '127.0.0.1', '1519815159', '__ci_last_regenerate|i:1519815159;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ufa22mtpcs6k38qjklekbk2ob5p0q3qi', '127.0.0.1', '1519816251', '__ci_last_regenerate|i:1519816251;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nat77ved084chs0afp9bjq7sjkc47i23', '127.0.0.1', '1519816623', '__ci_last_regenerate|i:1519816623;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6acetkencmciill8trgddocvi744ajov', '127.0.0.1', '1519816992', '__ci_last_regenerate|i:1519816992;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0h6cvhgnobbo7npo3qmi43dvg75k5p7a', '127.0.0.1', '1519817316', '__ci_last_regenerate|i:1519817316;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('41uer56b2qrlqpmmrs5lbcgh3nh40gu0', '127.0.0.1', '1519817858', '__ci_last_regenerate|i:1519817858;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1olu8khm980uutnpfk4ri24m5l2rmvh', '127.0.0.1', '1519818446', '__ci_last_regenerate|i:1519818446;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76f9dfvd02g91nbdae79hqrhpro23vlu', '127.0.0.1', '1519821021', '__ci_last_regenerate|i:1519821021;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c65sh77k30k33uend0ipesio56dls0u3', '127.0.0.1', '1519819466', '__ci_last_regenerate|i:1519819466;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vtbsr5i5r0470l7mluliks6q2hbh6ns0', '127.0.0.1', '1519820266', '__ci_last_regenerate|i:1519820266;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vb95sm9u60drv9s88c4svsciq5abtomm', '127.0.0.1', '1519819805', '__ci_last_regenerate|i:1519819804;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vi6ech2rt8di1edhumsn2pieg0l61vok', '127.0.0.1', '1519819836', '__ci_last_regenerate|i:1519819836;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ud4n82r4uio2m1ru537pm5aramhkg4j', '127.0.0.1', '1519819917', '__ci_last_regenerate|i:1519819917;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o40af84uvaoflefk832kpgmoaj95fhp0', '127.0.0.1', '1519819921', '__ci_last_regenerate|i:1519819921;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e3cs2eqg37a1m0qle4bb0obc8vo3t87d', '127.0.0.1', '1519819933', '__ci_last_regenerate|i:1519819933;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qsjv92d3obmbebcr7k723c47ijf1mfd2', '127.0.0.1', '1519820002', '__ci_last_regenerate|i:1519820002;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jk472nqroa5737cv3tdamv9j8hebrvtn', '127.0.0.1', '1519820011', '__ci_last_regenerate|i:1519820011;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gst52hojirngmcoji6uh9g7kvkk61u0u', '127.0.0.1', '1519820043', '__ci_last_regenerate|i:1519820043;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k1cqoee9tpmhae17u4mcm8q00ja26n4b', '127.0.0.1', '1519820065', '__ci_last_regenerate|i:1519820065;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m5hnj2q16gf2s149osj0ktmq8n84sum8', '127.0.0.1', '1519820104', '__ci_last_regenerate|i:1519820104;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mfhbf056trr23cdvq56k2dkaq2acpnmg', '127.0.0.1', '1519820116', '__ci_last_regenerate|i:1519820116;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dcjjuljcrf9115k7gaug84hlih0n4642', '127.0.0.1', '1519820131', '__ci_last_regenerate|i:1519820131;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1m2c3rcfp7qh491u22903p5brpokb0kq', '127.0.0.1', '1519820135', '__ci_last_regenerate|i:1519820135;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tv72gqtiues65ht7al2uolt6v0lrglah', '127.0.0.1', '1519821195', '__ci_last_regenerate|i:1519821195;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gskuvgi7pffelo0iq4d2p9q4d4ls2n76', '127.0.0.1', '1519820339', '__ci_last_regenerate|i:1519820339;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6j8563jhjb7ecqmuaabgf8tg803va8v', '127.0.0.1', '1519820371', '__ci_last_regenerate|i:1519820371;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gdej6pglcammdhc5p8qf3lu68tnri9s9', '127.0.0.1', '1519820390', '__ci_last_regenerate|i:1519820390;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('odhdt3rqvvcjtpse07segfn1b9643eug', '127.0.0.1', '1519820451', '__ci_last_regenerate|i:1519820451;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4qmriq1ico8vm6ceoa1m7lqvorarl5c2', '127.0.0.1', '1519820476', '__ci_last_regenerate|i:1519820476;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9s4noi8ufa3p7koa81p4sd2ig7rgvbot', '127.0.0.1', '1519820492', '__ci_last_regenerate|i:1519820492;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('prksm5eolu2i9uko95iadu11ulhdbn1c', '127.0.0.1', '1519820535', '__ci_last_regenerate|i:1519820535;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ckpd36c70jo3ullt57bqqdv16pgt0hv0', '127.0.0.1', '1519820615', '__ci_last_regenerate|i:1519820615;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aifloqu6gtudv4c8i4i7bq8r33kuic7u', '127.0.0.1', '1519820630', '__ci_last_regenerate|i:1519820630;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('702ulamfvlnv8e1idvi7t2oiip2roubu', '127.0.0.1', '1519820646', '__ci_last_regenerate|i:1519820646;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80l0r7tid8fo2epbee2965eck3l39h24', '127.0.0.1', '1519820660', '__ci_last_regenerate|i:1519820660;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hr0428akscoo0vnsp75ihikr82rf7n80', '127.0.0.1', '1519820683', '__ci_last_regenerate|i:1519820683;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j8rmdrfove9uc1qpih3f6fjpptdnpa0j', '127.0.0.1', '1519820708', '__ci_last_regenerate|i:1519820708;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nahffie6iclkm818ut48t0h2u16d24l9', '127.0.0.1', '1519820762', '__ci_last_regenerate|i:1519820762;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7hb0jpeg1nflpffanlmmrv6g542uj6un', '127.0.0.1', '1519820767', '__ci_last_regenerate|i:1519820767;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g059l1glf686h56tpl2gvlc0n78407r5', '127.0.0.1', '1519820838', '__ci_last_regenerate|i:1519820838;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbou672k2saemlpusn9ui0ssu6no7952', '127.0.0.1', '1519821009', '__ci_last_regenerate|i:1519821009;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k8dt064ig0aap8jv15o4uq9ucmdfjq1h', '127.0.0.1', '1519826297', '__ci_last_regenerate|i:1519826297;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhbfq40981h53nkfs50i4lv4vsa4ljsm', '127.0.0.1', '1519821029', '__ci_last_regenerate|i:1519821029;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6vf0va0s8fasfpgaknm23ebkpmf2grnu', '127.0.0.1', '1519821050', '__ci_last_regenerate|i:1519821050;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jm2jbn8m6t71lr6ggc5i370dslelihls', '127.0.0.1', '1519821069', '__ci_last_regenerate|i:1519821069;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gn7mlcsr70tqmij0jb5jm2su5mjmnghu', '127.0.0.1', '1519821116', '__ci_last_regenerate|i:1519821116;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lj1tqc7ucabk7dreljltphcvi45fflip', '127.0.0.1', '1519821190', '__ci_last_regenerate|i:1519821190;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lutv3jipg06v1465tioibclu5et29rb0', '127.0.0.1', '1519825619', '__ci_last_regenerate|i:1519825619;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q6ll7v1vk623g9r1a8qm6809rfpmlcgs', '127.0.0.1', '1519821203', '__ci_last_regenerate|i:1519821203;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vgiugqspcbadrr6sc2lk1trjh3fqk4dd', '127.0.0.1', '1519821365', '__ci_last_regenerate|i:1519821365;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8sj5f0i5ebdesco8ssudedc9tl17u868', '127.0.0.1', '1519821376', '__ci_last_regenerate|i:1519821376;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mbildnuogaflj3hlnoltbl3t2jgvd6g0', '127.0.0.1', '1519821518', '__ci_last_regenerate|i:1519821518;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ldioisohu45l3kd10er0f7c10q8a3hc5', '127.0.0.1', '1519821567', '__ci_last_regenerate|i:1519821567;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nk6ab027amgekijaba1m2n2ujp7shltb', '127.0.0.1', '1519821580', '__ci_last_regenerate|i:1519821580;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ehn3mhtoedmb7spagfe8cddu6oo13lfi', '127.0.0.1', '1519821617', '__ci_last_regenerate|i:1519821617;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t7it52494702uaaklgp8gcttsots5h65', '127.0.0.1', '1519821631', '__ci_last_regenerate|i:1519821631;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46q2sohp1uv0cilrl7ujrvioke6761kv', '127.0.0.1', '1519821657', '__ci_last_regenerate|i:1519821657;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4v42i0qni16pj9cdt15d4sdb2t4adk2b', '127.0.0.1', '1519821676', '__ci_last_regenerate|i:1519821676;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0e9crvjpgs4acqd9db4r8h4f7b00870', '127.0.0.1', '1519821691', '__ci_last_regenerate|i:1519821691;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2lca1855836fknpmc3rgfk3o9fot2e6b', '127.0.0.1', '1519821739', '__ci_last_regenerate|i:1519821739;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5aqlhnmalvb48oflui4tk7vm00n51abn', '127.0.0.1', '1519824079', '__ci_last_regenerate|i:1519824078;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0udr9g0uecgtn46gh2qg919me17hlvc2', '127.0.0.1', '1519824095', '__ci_last_regenerate|i:1519824095;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1410c3uo46adtg7rou8nbv5tic0168tp', '127.0.0.1', '1519824181', '__ci_last_regenerate|i:1519824181;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nt5bltkb6aog1meq2gggcd1n25435qo9', '127.0.0.1', '1519824211', '__ci_last_regenerate|i:1519824211;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iocn16rl84gqsikpsnf1oarseh9deu5q', '127.0.0.1', '1519824446', '__ci_last_regenerate|i:1519824446;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8l5atncuq75mnh690tmkltq114iu9bjv', '127.0.0.1', '1519824460', '__ci_last_regenerate|i:1519824460;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c2bcq4gkribedr0uortkvrc2ch3cp42p', '127.0.0.1', '1519824469', '__ci_last_regenerate|i:1519824469;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9hve7taj2gp7h4oqn6llg1i8uorr7f79', '127.0.0.1', '1519824742', '__ci_last_regenerate|i:1519824742;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ouubi4j2fcp4ejoavnbg6spq3ufg7vb8', '127.0.0.1', '1519824868', '__ci_last_regenerate|i:1519824868;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c91aeauhbbm7310fdd35k5tr5k5aenpk', '127.0.0.1', '1519824959', '__ci_last_regenerate|i:1519824959;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4dv1vi4l576dsejch4mhfvqrls810ttk', '127.0.0.1', '1519824984', '__ci_last_regenerate|i:1519824984;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b27aod4j89sn5npbcu4r1kb4edsq41lq', '127.0.0.1', '1519824996', '__ci_last_regenerate|i:1519824996;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8hvv8vjncu2g1jhmj7k0jsbnm9isdpmu', '127.0.0.1', '1519825002', '__ci_last_regenerate|i:1519825002;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7qbrndb8k2l4i950dfipte8qk16lfrll', '127.0.0.1', '1519825014', '__ci_last_regenerate|i:1519825014;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rk49cueecpac0m64se89qbhasu3cl86t', '127.0.0.1', '1519825059', '__ci_last_regenerate|i:1519825059;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ln413msqm7uul9sc947ao6nerun6sb8k', '127.0.0.1', '1519825074', '__ci_last_regenerate|i:1519825074;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f86lvuc8so9fmghfoq99v40fcs0k4oj4', '127.0.0.1', '1519825087', '__ci_last_regenerate|i:1519825087;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l0u4s0vo6t2uqeo3bbci0fgjo6rrl6dl', '127.0.0.1', '1519825100', '__ci_last_regenerate|i:1519825099;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3lbb439b68d4mfrgnu0thhe5of2uslvp', '127.0.0.1', '1519825167', '__ci_last_regenerate|i:1519825167;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pehtad48q1t3km3jm5t191og8ek2r2ek', '127.0.0.1', '1519825177', '__ci_last_regenerate|i:1519825177;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a0akg0u6al46kkcj3us42bdi3etec1n', '127.0.0.1', '1519825193', '__ci_last_regenerate|i:1519825193;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qf5tmjko6jb4akj6f71defja3gr7qbqo', '127.0.0.1', '1519825292', '__ci_last_regenerate|i:1519825292;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g3fa232e2isjk1nfpt9koghqnqqd2isf', '127.0.0.1', '1519828315', '__ci_last_regenerate|i:1519828315;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('imi0o6pulgh7qpep8dbkg6qenb9ucq38', '127.0.0.1', '1519826685', '__ci_last_regenerate|i:1519826685;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fm6ttcikv6nv0etvq8o26208ftfff29a', '127.0.0.1', '1519826991', '__ci_last_regenerate|i:1519826991;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1oo0b739unnhfojpoua809qd0h7hikln', '127.0.0.1', '1519827315', '__ci_last_regenerate|i:1519827315;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('47hucqn50q3f4kte2ju3no16gaos3j7h', '127.0.0.1', '1519827058', '__ci_last_regenerate|i:1519827058;red_url|s:23:\"admin/intents/intent/34\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6t5kb820t2u9fcfvr5lgvf51npkp7qu', '127.0.0.1', '1519827058', '__ci_last_regenerate|i:1519827058;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7leocn8auq25lu5s5u6geqfaqldom14i', '127.0.0.1', '1519827619', '__ci_last_regenerate|i:1519827619;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ka0vpts732ocnmcje2k1ko12lj40r6ue', '127.0.0.1', '1519828050', '__ci_last_regenerate|i:1519828050;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n0otcpnq0hvkuetqvt0235c29nr0i0o6', '127.0.0.1', '1519829711', '__ci_last_regenerate|i:1519829711;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i5g5av5umfs5itld8tbsfpd2r56hdnco', '127.0.0.1', '1519831993', '__ci_last_regenerate|i:1519831993;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vqdigl8bqbanpomr2so617qfnvp2f7mo', '127.0.0.1', '1519828330', '__ci_last_regenerate|i:1519828329;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pcm4li997em5kp1lobv40gnup66shmv7', '127.0.0.1', '1519828356', '__ci_last_regenerate|i:1519828356;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6gvqrs1tehm5ntd0rntai91r4ilde5vh', '127.0.0.1', '1519828412', '__ci_last_regenerate|i:1519828412;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8tosfbvqkt1sciaofv404rf3nseithc6', '127.0.0.1', '1519828492', '__ci_last_regenerate|i:1519828492;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2q00vuiph9nfodqvbkc6sbcuq2numsh0', '127.0.0.1', '1519828543', '__ci_last_regenerate|i:1519828543;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hqim22acht4p8pjmbusb6rao54a1rp8j', '127.0.0.1', '1519828879', '__ci_last_regenerate|i:1519828879;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fuk246hf27e334e5nsuv795nk0ckacdn', '127.0.0.1', '1519828972', '__ci_last_regenerate|i:1519828972;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n1a61lc6mh8q7jvcilh426smp7suc5va', '127.0.0.1', '1519829099', '__ci_last_regenerate|i:1519829098;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gptj9dmr407dh4pc4tiktl63ps3u46ek', '127.0.0.1', '1519829243', '__ci_last_regenerate|i:1519829243;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k389udtb3ctjdoq6i179bh5r5e7ko975', '127.0.0.1', '1519829289', '__ci_last_regenerate|i:1519829288;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1q5bpe7je0gr0s6dokv74ehukn8mkrrj', '127.0.0.1', '1519829305', '__ci_last_regenerate|i:1519829305;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qlrk23jbmm2rbcs10fru5cuvp6aggho4', '127.0.0.1', '1519829636', '__ci_last_regenerate|i:1519829636;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('193sllr6ne6fi0pn8l4mt85qdm868t72', '127.0.0.1', '1519830158', '__ci_last_regenerate|i:1519830158;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6t49g8rdoathsnd0cjskif1ldjck02i5', '127.0.0.1', '1519830002', '__ci_last_regenerate|i:1519830002;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9dn2m0ac28ki0vf1ruui4p7q10sefe4', '127.0.0.1', '1519831899', '__ci_last_regenerate|i:1519831899;staff_user_id|s:1:\"1\";staff_logged_in|b:1;message-success|s:29:\"Intents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75tq1e31aungl90bt6fobi03m8tlqrv5', '127.0.0.1', '1519830401', '__ci_last_regenerate|i:1519830401;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bs7mmhvi69rq6ni5je4hdbfo617ls3fr', '127.0.0.1', '1519830577', '__ci_last_regenerate|i:1519830577;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dsq37oejdi6a863mg3gddomolaib8em8', '127.0.0.1', '1519830611', '__ci_last_regenerate|i:1519830610;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfrcud1o4ate7svfile888suej4m8lq8', '127.0.0.1', '1519830689', '__ci_last_regenerate|i:1519830689;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2op04qk72nv6qqp6plm965r9utompbjp', '127.0.0.1', '1519830731', '__ci_last_regenerate|i:1519830731;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hi1n8m848rfdb5oqpq6bq6kokuo16om5', '127.0.0.1', '1519830746', '__ci_last_regenerate|i:1519830745;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oqi6oq71ffgr20o7ig1aol749b7gaakr', '127.0.0.1', '1519830868', '__ci_last_regenerate|i:1519830868;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rjspnbj43m0o00ledcujhcvf053nn5dr', '127.0.0.1', '1519830877', '__ci_last_regenerate|i:1519830877;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('omqnd1spbue4ngk26l9qklgoqrl176ra', '127.0.0.1', '1519830934', '__ci_last_regenerate|i:1519830933;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98t6lk4v5d3erujk31njqomgg8lkn5i8', '127.0.0.1', '1519830939', '__ci_last_regenerate|i:1519830939;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h75i8541n02rud2jbel7d0hgfgihh86r', '127.0.0.1', '1519831096', '__ci_last_regenerate|i:1519831096;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4v6kemim5er45hd5g2o59mg9kb82fpbo', '127.0.0.1', '1519831207', '__ci_last_regenerate|i:1519831206;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('egst7ov1r4b59p26gfekkl59r8rlrara', '127.0.0.1', '1519831214', '__ci_last_regenerate|i:1519831214;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('klpcv100j8tcmkqs9f13e5luln2825v3', '127.0.0.1', '1519831244', '__ci_last_regenerate|i:1519831244;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2o6pg1f783mrpmcmt7hf7i3onno47r6', '127.0.0.1', '1519831249', '__ci_last_regenerate|i:1519831249;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a33dotpdn6669of5fvfenkq05r3097tu', '127.0.0.1', '1519831307', '__ci_last_regenerate|i:1519831306;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9nrsofqe4t93ru4ujljhulbqpgqvt4e2', '127.0.0.1', '1519831329', '__ci_last_regenerate|i:1519831329;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9l3o9kpc25dvjanoea3flvpnl9m9p15j', '127.0.0.1', '1519831332', '__ci_last_regenerate|i:1519831332;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sljhh4bkok1dlhba8bpi8msrlossqkqr', '127.0.0.1', '1519831371', '__ci_last_regenerate|i:1519831371;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('if71kelujggrf0v5ccppkb88afkjb6ge', '127.0.0.1', '1519831377', '__ci_last_regenerate|i:1519831377;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c94jlrd6maublrgo9b8p5o98rokt609f', '127.0.0.1', '1519831387', '__ci_last_regenerate|i:1519831387;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pi0pgbflieesmr67hb3n9n7dmh3503in', '127.0.0.1', '1519832503', '__ci_last_regenerate|i:1519832503;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69cnkkrcl6m8fh86fno50aolbq50014o', '127.0.0.1', '1519831909', '__ci_last_regenerate|i:1519831908;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r26pe162cme0fr7cnmgohvpiv61q1m70', '127.0.0.1', '1519831916', '__ci_last_regenerate|i:1519831916;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c128702is28v4ipkgutigcnfkr6ntj6e', '127.0.0.1', '1519835865', '__ci_last_regenerate|i:1519835865;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1jtmq1gvm1e9b91lji02g7alohdp477s', '127.0.0.1', '1519832876', '__ci_last_regenerate|i:1519832876;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lpvqmu1i8q4rigthmomf7tdfm6gqpjil', '127.0.0.1', '1519833277', '__ci_last_regenerate|i:1519833277;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ocdl13c8qc2f4el9bs10o98gafdl5mp4', '127.0.0.1', '1519833579', '__ci_last_regenerate|i:1519833579;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dgvpjvvhc5s98jt8injj30si57t0p2qe', '127.0.0.1', '1519833884', '__ci_last_regenerate|i:1519833884;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t42ke970ippa1qcs361857gll3jrgflr', '127.0.0.1', '1519834421', '__ci_last_regenerate|i:1519834421;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g0cov3d68h144voncir7m2kq2fq0hm0k', '127.0.0.1', '1519834845', '__ci_last_regenerate|i:1519834845;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eorftvqjc1o3pgdpksl4a2b91tl0l9kc', '127.0.0.1', '1519835162', '__ci_last_regenerate|i:1519835162;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i93ltlhor06jbb13r4b4e9qjnagehphu', '127.0.0.1', '1519835482', '__ci_last_regenerate|i:1519835482;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obupl1u29gjogj2nd5bu4oj6erv55amb', '127.0.0.1', '1519839777', '__ci_last_regenerate|i:1519839777;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2jgqi6htr4m2iftsiqgjm5t543pkphjr', '127.0.0.1', '1519836189', '__ci_last_regenerate|i:1519836189;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('npqk2cobfme3fmt21mr337lu4j6frm78', '127.0.0.1', '1519835877', '__ci_last_regenerate|i:1519835877;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s8scdtaj4grdvpqsjjuuj1lg2fpkuge8', '127.0.0.1', '1519836642', '__ci_last_regenerate|i:1519836642;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b26l42j8lvbtieeohdmggotsdlr4h0pk', '127.0.0.1', '1519836990', '__ci_last_regenerate|i:1519836990;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75dgeemu6v08pv8uglln0563nkth233t', '127.0.0.1', '1519837461', '__ci_last_regenerate|i:1519837461;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fremc9b2g21av0tf4dksmnp0q48l4h9s', '127.0.0.1', '1519838107', '__ci_last_regenerate|i:1519838107;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd9kcfqt00ih4e20btfaq9skajoae9kg', '127.0.0.1', '1519839288', '__ci_last_regenerate|i:1519839288;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hrk9vgl3e3k8uci5i39mmkbdr5gq9m98', '127.0.0.1', '1519839692', '__ci_last_regenerate|i:1519839692;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d12atsl45dklnrk8fgrma1aisojf4tog', '127.0.0.1', '1519840247', '__ci_last_regenerate|i:1519840247;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3ee7pj7i7ev5guuqs0g72g1kghbj1sr', '127.0.0.1', '1519840965', '__ci_last_regenerate|i:1519840965;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vj07llb6v69h26d2p0nbulvgb7uvnfha', '127.0.0.1', '1519840848', '__ci_last_regenerate|i:1519840848;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8vpc789ksoomhc07ovukdj4s9tchd2vq', '127.0.0.1', '1519841794', '__ci_last_regenerate|i:1519841794;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82dkvk6m4hv1347i8hpqp974km3uqb5q', '127.0.0.1', '1519840972', '__ci_last_regenerate|i:1519840965;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba45s9tl278494327qpmhp7rca80n8jp', '127.0.0.1', '1519852577', '__ci_last_regenerate|i:1519852577;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d8gdfl65j80i74jbrcklguiu875l3bhu', '127.0.0.1', '1519853513', '__ci_last_regenerate|i:1519853513;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbf5bqrlh5vd0fjocqu0i40hfcc97iuk', '127.0.0.1', '1519853845', '__ci_last_regenerate|i:1519853845;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q50apkkefmjiu0q62bs3k1qtsec8qncs', '127.0.0.1', '1519854211', '__ci_last_regenerate|i:1519854211;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1d2ehs114034pqb2gki1murl92m2i1cb', '127.0.0.1', '1519854860', '__ci_last_regenerate|i:1519854860;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fi0f4a1cc2pvgu9tpr32ia4hmltusvcr', '127.0.0.1', '1519854516', '__ci_last_regenerate|i:1519854515;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4m34o0rjusho8ri4ur03b93d0qc0tv0u', '127.0.0.1', '1519854634', '__ci_last_regenerate|i:1519854634;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1i7tjt9u0r9ouu0rkj5jhivdl3huhe90', '127.0.0.1', '1519854742', '__ci_last_regenerate|i:1519854742;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kg7fq5v0tprt64vv2ufi61s0hbebq5jt', '127.0.0.1', '1519854796', '__ci_last_regenerate|i:1519854796;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jcd3c72aohs8163bt66654fucf7j40i4', '127.0.0.1', '1519854856', '__ci_last_regenerate|i:1519854856;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96tvt03kg88uf9ug5pipjr1qel3p7aav', '127.0.0.1', '1519855364', '__ci_last_regenerate|i:1519855364;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('22tpk5ip5jcc4q1h9p0qkq540s7dupek', '127.0.0.1', '1519854866', '__ci_last_regenerate|i:1519854866;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('logvmnb2h2dgr2k72n9mhhbib95i6cik', '127.0.0.1', '1519854898', '__ci_last_regenerate|i:1519854898;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ivhv9k4qpscs3s37pmkm1lopc98vgqf9', '127.0.0.1', '1519854959', '__ci_last_regenerate|i:1519854959;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qhiiecslmj0717eiu8g0k6ufo1v3dl5r', '127.0.0.1', '1519855000', '__ci_last_regenerate|i:1519855000;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u2a8onn7ip2dl350kn3senke50e7oh0i', '127.0.0.1', '1519855232', '__ci_last_regenerate|i:1519855232;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j2oi5cpk6nlg2eps7d9ukko13g06d2j5', '127.0.0.1', '1519855249', '__ci_last_regenerate|i:1519855249;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ecs7sc2rjl5fjuh2027056b4so6kh496', '127.0.0.1', '1519855263', '__ci_last_regenerate|i:1519855263;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n2nhq4nbaj9d2rtk0evkpbthggk2mrtr', '127.0.0.1', '1519855273', '__ci_last_regenerate|i:1519855273;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qeokgh7qi9pqi1bualgeu677f6kgl80u', '127.0.0.1', '1519855307', '__ci_last_regenerate|i:1519855307;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2q5n0kj9bjl3nmlbcue9fbu5lvp8gil2', '127.0.0.1', '1519855359', '__ci_last_regenerate|i:1519855359;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o2pgmf74kfqcm78rphee7d1m3ittjumn', '127.0.0.1', '1519856110', '__ci_last_regenerate|i:1519856110;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('njbvlpp2v67psu7n2ni4totscb57nusk', '127.0.0.1', '1519855386', '__ci_last_regenerate|i:1519855386;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mjuaf5dk6utmkmsr3mnnempnoj9sc98q', '127.0.0.1', '1519855449', '__ci_last_regenerate|i:1519855449;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k8eetmr4mk3luvn0usm8cga6h7htpntf', '127.0.0.1', '1519855482', '__ci_last_regenerate|i:1519855482;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l91a6k7d5vgbre0b4qp8k6pantde6qrg', '127.0.0.1', '1519855498', '__ci_last_regenerate|i:1519855498;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fjdd6bk9js484c5aufimds955f91accv', '127.0.0.1', '1519855526', '__ci_last_regenerate|i:1519855526;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6jat8o6so115n0sgh9lnajnh1jb71j5b', '127.0.0.1', '1519855574', '__ci_last_regenerate|i:1519855574;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2vrt1tpsekbjndrai7v0m2m95568ks9c', '127.0.0.1', '1519855595', '__ci_last_regenerate|i:1519855595;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1m4ua7pt5q8n9sod0lol4hb298m5n5iq', '127.0.0.1', '1519855618', '__ci_last_regenerate|i:1519855618;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r8u7hk5iskfdf4u2i26tcrnv9mppvhce', '127.0.0.1', '1519855621', '__ci_last_regenerate|i:1519855621;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b8p6r5olveihlpgtpura5kede8011l2', '127.0.0.1', '1519855725', '__ci_last_regenerate|i:1519855725;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1jo7bufq9atg4dnc7a2e618dk7gj65l', '127.0.0.1', '1519855739', '__ci_last_regenerate|i:1519855739;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8p90o726p1m5e73l757ep2updncshju9', '127.0.0.1', '1519855793', '__ci_last_regenerate|i:1519855793;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dvtr4l27eoaej2ds42ivlitrhnmee972', '127.0.0.1', '1519855811', '__ci_last_regenerate|i:1519855811;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nqoq44ppc53j0t61jhdourmr4m5ognc2', '127.0.0.1', '1519855893', '__ci_last_regenerate|i:1519855892;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e9sp171i6im67b2s8uckh9297c895ju0', '127.0.0.1', '1519855908', '__ci_last_regenerate|i:1519855908;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pkh8lascn3dm2i1maqbguguiorl7n51q', '127.0.0.1', '1519855951', '__ci_last_regenerate|i:1519855951;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ri6broljpgr0rjrs9mnefhergsdpgnu', '127.0.0.1', '1519855974', '__ci_last_regenerate|i:1519855974;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8lpllvtrcamf9v774jnfkhtaflg9kmog', '127.0.0.1', '1519855980', '__ci_last_regenerate|i:1519855980;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q5kje46jaous53kgb97m8ee3r4bbml0j', '127.0.0.1', '1519856284', '__ci_last_regenerate|i:1519856110;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lf60nrr9fs981nut9m07immkj23slt3o', '127.0.0.1', '1519856115', '__ci_last_regenerate|i:1519856115;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbn1e6cr81gs4apu3t0gchieu5mb2m93', '127.0.0.1', '1519856156', '__ci_last_regenerate|i:1519856156;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7vhooflvcg65h6tbb0velsbb5v5lph89', '127.0.0.1', '1519856166', '__ci_last_regenerate|i:1519856166;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ff9fvvl8ncnp9lmbaa22a15h2kmept0', '127.0.0.1', '1519856214', '__ci_last_regenerate|i:1519856214;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('00s5opdk4kptbo09ifcjih9b2rg77l3h', '127.0.0.1', '1519856234', '__ci_last_regenerate|i:1519856234;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h4oqal1bocvos269j68vfbuq120de341', '127.0.0.1', '1519887815', '__ci_last_regenerate|i:1519887815;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jjude7n7c3p2f7urqvr413vs3uhcl3q2', '127.0.0.1', '1519887807', '__ci_last_regenerate|i:1519887807;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('00chad64m4hcvojfhfiicohs8aa4qq37', '127.0.0.1', '1519887812', '__ci_last_regenerate|i:1519887812;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('543td36sumb867sr09sp8uuk5568oh50', '127.0.0.1', '1519888283', '__ci_last_regenerate|i:1519888283;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8u61r6lk2g6k974v1ahqtj67680gn2qk', '127.0.0.1', '1519888593', '__ci_last_regenerate|i:1519888593;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4o2d833ob4ledm8gj2qscad71010nqkj', '127.0.0.1', '1519889189', '__ci_last_regenerate|i:1519889189;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ccf07fohb10ro9r55gk5mp2vr73nk7lr', '127.0.0.1', '1519889740', '__ci_last_regenerate|i:1519889740;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('alp58bh6blh5v6i9k9mhsa4bb8u6uu00', '127.0.0.1', '1519890877', '__ci_last_regenerate|i:1519890877;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfa11cats1rm84ge1fcl506pddvqnnkf', '127.0.0.1', '1519890585', '__ci_last_regenerate|i:1519890585;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ifr5oako3s1muj170l5tmeikdbirmcm1', '127.0.0.1', '1519890710', '__ci_last_regenerate|i:1519890710;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qsvoj0m7qtf8lvfh6jqpfp4825d7cmcj', '127.0.0.1', '1519890731', '__ci_last_regenerate|i:1519890731;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8npetkd7oo7l439d8a2g6eg0jjpp9e73', '127.0.0.1', '1519890741', '__ci_last_regenerate|i:1519890741;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('482ske2ip9oqftqfchi1r4ssp6dt5qoq', '127.0.0.1', '1519890804', '__ci_last_regenerate|i:1519890804;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rfdt1psgvcbds8p225u3bn4u4t8llrok', '127.0.0.1', '1519890845', '__ci_last_regenerate|i:1519890845;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l449l2dsoca7rtcs2uqh1c318sn7k8qs', '127.0.0.1', '1519891598', '__ci_last_regenerate|i:1519891598;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hcfvn09nhhj42er8em1kcs6mfnkrcs9a', '127.0.0.1', '1519890926', '__ci_last_regenerate|i:1519890926;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62vmhstkjkbpknj19vv2hajaosp0kaen', '127.0.0.1', '1519891041', '__ci_last_regenerate|i:1519891041;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kdfva78hejetifc5nui3b1en1jcmus1t', '127.0.0.1', '1519891048', '__ci_last_regenerate|i:1519891048;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gt8j6d1lopl4p8k18n1h6kvp7fepd6f3', '127.0.0.1', '1519891190', '__ci_last_regenerate|i:1519891190;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t2hhh97pjb81311u22oeg0ehniprabjh', '127.0.0.1', '1519891242', '__ci_last_regenerate|i:1519891242;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8i9giuhn54li0h4p31lb8msheruj7pc2', '127.0.0.1', '1519891256', '__ci_last_regenerate|i:1519891256;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1qdgji8b9bgnvh7n92vc9q7bntcun0fo', '127.0.0.1', '1519891347', '__ci_last_regenerate|i:1519891347;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j5mnekeskc0u1nk9c462rvm1g91i4cok', '127.0.0.1', '1519891359', '__ci_last_regenerate|i:1519891359;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pnoh6qn53q12gel9hmn1ieb1to6tinli', '127.0.0.1', '1519891413', '__ci_last_regenerate|i:1519891413;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i6l6cbq6r4g6bsk7aunsnuco4k025au1', '127.0.0.1', '1519891447', '__ci_last_regenerate|i:1519891447;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rmgh0jd0oj330lrtop3alo9kf00js7lf', '127.0.0.1', '1519891499', '__ci_last_regenerate|i:1519891499;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q5e52otg5qtthpno95s83s816ibpv23e', '127.0.0.1', '1519891502', '__ci_last_regenerate|i:1519891502;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ipdpnkr9i16uffhhhpvpmcfqk8frdjav', '127.0.0.1', '1519891542', '__ci_last_regenerate|i:1519891542;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uev03sbv4datoo65on98q1s6c7o5562i', '127.0.0.1', '1519891546', '__ci_last_regenerate|i:1519891546;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3fiv4fhjgumdjh0a78krfhn8r0c2i3v4', '127.0.0.1', '1519891550', '__ci_last_regenerate|i:1519891550;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tu93b7c2l3pi406hr3dqn4j9ddl80rsh', '127.0.0.1', '1519891911', '__ci_last_regenerate|i:1519891911;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;message-success|s:28:\"Agents updated successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q4up2fo7i6gs6cdip8d31crfkd01uikl', '127.0.0.1', '1519891749', '__ci_last_regenerate|i:1519891749;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tgll9d0bn1j5272kecohhernmg9c23f3', '127.0.0.1', '1519892704', '__ci_last_regenerate|i:1519892704;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8ieecs6cmu321lmn1b0f85er67quuum', '127.0.0.1', '1519891916', '__ci_last_regenerate|i:1519891916;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h87vi0scl32s4lqmj6rihl3qlc93ljsq', '127.0.0.1', '1519891924', '__ci_last_regenerate|i:1519891923;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o07lkfchcfres03rl2bs39t6c8e1j1e7', '127.0.0.1', '1519892069', '__ci_last_regenerate|i:1519892069;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qs3n9dep7d8srpe00vgg3be3lnq243u7', '127.0.0.1', '1519892158', '__ci_last_regenerate|i:1519892158;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p6mdekeir4ra9e94h7hqj30lbmvinh92', '127.0.0.1', '1519892329', '__ci_last_regenerate|i:1519892329;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vqvp7onbrr4n2mg7ruikouo1uu40rlqf', '127.0.0.1', '1519892341', '__ci_last_regenerate|i:1519892341;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6d3i3bp5a7rgco7b807ndbm0gv8s88i2', '127.0.0.1', '1519892443', '__ci_last_regenerate|i:1519892443;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0t66ev9n15ukv9hp6p7385gu7r0p18t0', '127.0.0.1', '1519892678', '__ci_last_regenerate|i:1519892678;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3obhvjrct4mq42edbt0m9rdku216np61', '127.0.0.1', '1519893808', '__ci_last_regenerate|i:1519893808;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qgm28aqqapgv7vd096vls8vvs514bljh', '127.0.0.1', '1519892972', '__ci_last_regenerate|i:1519892972;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g9ngc4hvgsg09hd55ueefm6p15t2j0hq', '127.0.0.1', '1519892991', '__ci_last_regenerate|i:1519892991;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kmsnu6bkpu4or0jpboinhhis808ni323', '127.0.0.1', '1519893012', '__ci_last_regenerate|i:1519893012;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5m35tjpt7gn1fqk5vlhbu7o8crlavqiv', '127.0.0.1', '1519893035', '__ci_last_regenerate|i:1519893035;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lklnr3d1iciauhovhei8me9n5k3b7h6c', '127.0.0.1', '1519893454', '__ci_last_regenerate|i:1519893454;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8ad7bt1m3om1kjldcn3kn9b1tqijf5j', '127.0.0.1', '1519893475', '__ci_last_regenerate|i:1519893475;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2omj5m78fesphk4622nqtvlatvs7q52', '127.0.0.1', '1519893754', '__ci_last_regenerate|i:1519893754;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7oeju081rg5210j1fgb7caksjtk1p7hl', '127.0.0.1', '1519893758', '__ci_last_regenerate|i:1519893758;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rllar619kqmjv7lgc2h5lpo1roldfkdl', '127.0.0.1', '1519893791', '__ci_last_regenerate|i:1519893791;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nk41aumf8hocrrjb4i4ek6qgnpe67ic0', '127.0.0.1', '1519893795', '__ci_last_regenerate|i:1519893795;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4h5stfe37hc6ctp41b9ckjpik087evt2', '127.0.0.1', '1519893799', '__ci_last_regenerate|i:1519893799;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vvpa5lmk2pdinh8k3a393omkgvcvrvfo', '127.0.0.1', '1519894192', '__ci_last_regenerate|i:1519894192;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99gnve30q71ed17atq4dlagvanhl4s6l', '127.0.0.1', '1519893857', '__ci_last_regenerate|i:1519893857;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aeia34d021q4c24ecevspiicq0h8hi48', '127.0.0.1', '1519893862', '__ci_last_regenerate|i:1519893862;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cgeihldtbl71uln3imj4dp5gllqc34a5', '127.0.0.1', '1519893867', '__ci_last_regenerate|i:1519893867;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('du1lm57c0r1mnb9fhtr2irl787oven4d', '127.0.0.1', '1519893874', '__ci_last_regenerate|i:1519893873;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bvgc5df72lf81etccjtg9se3ap530fil', '127.0.0.1', '1519893993', '__ci_last_regenerate|i:1519893993;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1mpvsjlf51up0audebj2pggbpjd3aplr', '127.0.0.1', '1519894131', '__ci_last_regenerate|i:1519894131;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('metdpa86c1pnn3je1iv9gc6kfb2hcre7', '127.0.0.1', '1519894137', '__ci_last_regenerate|i:1519894137;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89sd25mh4o3rf51mgm267toar83v5nuf', '127.0.0.1', '1519894142', '__ci_last_regenerate|i:1519894142;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3blknjcrlmcerhnjjboieive4fi1251i', '127.0.0.1', '1519894509', '__ci_last_regenerate|i:1519894509;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j6qre84v48be2fr43ghj7s6t4co98ijt', '127.0.0.1', '1519894311', '__ci_last_regenerate|i:1519894311;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0vi4t94ib68me416lnorjpsihqdtbc9a', '127.0.0.1', '1519894316', '__ci_last_regenerate|i:1519894316;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01c4oshepgprqip147mkcg97jmgdsb5u', '127.0.0.1', '1519894324', '__ci_last_regenerate|i:1519894323;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kqhfq2vni2c00mf1sf7q8bldb0aimu42', '127.0.0.1', '1519894329', '__ci_last_regenerate|i:1519894328;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fkcfrtes729jecphj3altmc0624tj4d9', '127.0.0.1', '1519894338', '__ci_last_regenerate|i:1519894338;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q6d5f67jj0ecmucfclndg61ah5n6kiub', '127.0.0.1', '1519894345', '__ci_last_regenerate|i:1519894345;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qbb9fi7nlg431b9gp7lik7tgdeof71t6', '127.0.0.1', '1519894353', '__ci_last_regenerate|i:1519894353;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frkdom05vp9gbitpb1d1poahn7382lfd', '127.0.0.1', '1519894360', '__ci_last_regenerate|i:1519894360;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cgqn2mfi9s2fvb18qgu6mhp7lnv0jkpr', '127.0.0.1', '1519894367', '__ci_last_regenerate|i:1519894367;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1578vmr5otkdf071unhmloon4lrndk17', '127.0.0.1', '1519894416', '__ci_last_regenerate|i:1519894416;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lp69kn2cbc2qnatq1fva4le9cuai2b6v', '127.0.0.1', '1519894449', '__ci_last_regenerate|i:1519894449;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3kg1o3llk3q3o3o51marhp01be8u8g31', '127.0.0.1', '1519894868', '__ci_last_regenerate|i:1519894868;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v28kkvdv3shl1a66ce8bjuj0mumvcuhg', '127.0.0.1', '1519895201', '__ci_last_regenerate|i:1519895201;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db8id737j5eefi43rb3radc0ug4f73fh', '127.0.0.1', '1519895505', '__ci_last_regenerate|i:1519895505;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jheo06b1ta0ffmv7kte5hgdondjksdlm', '127.0.0.1', '1519895874', '__ci_last_regenerate|i:1519895874;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uq8c3o62oqj7a9rvkekimp6ch02ojl7k', '127.0.0.1', '1519899301', '__ci_last_regenerate|i:1519899301;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35mgvjj2qhuna21751q4aih2pkv6f7c2', '127.0.0.1', '1519895811', '__ci_last_regenerate|i:1519895811;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qbdkfuulsi5op616khp629ie55pvhh4a', '127.0.0.1', '1519895819', '__ci_last_regenerate|i:1519895818;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7temc0j6rok7kujlrr2q3vb28mko02fe', '127.0.0.1', '1519895824', '__ci_last_regenerate|i:1519895824;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1svrc1tmu6gld8o5cdhmdslkrdogck7e', '127.0.0.1', '1519895829', '__ci_last_regenerate|i:1519895828;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p7msk4ap0qfo14lgn3jvqj6estk3oljh', '127.0.0.1', '1519895837', '__ci_last_regenerate|i:1519895837;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8mvc284cd7jqv68pajdfekehobrbqorp', '127.0.0.1', '1519895844', '__ci_last_regenerate|i:1519895844;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('um1e40tu1c5e8adt02f04odkirgs0lfa', '127.0.0.1', '1519895859', '__ci_last_regenerate|i:1519895859;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o1jf622c6sj0qh87aleg7946egrhlvvn', '127.0.0.1', '1519895864', '__ci_last_regenerate|i:1519895864;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fu1ecjl71f6dqqs0r7p5di75f8vq3o8j', '127.0.0.1', '1519896226', '__ci_last_regenerate|i:1519896226;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v78duretaudfhk27viegolpabovhs7lj', '127.0.0.1', '1519895894', '__ci_last_regenerate|i:1519895894;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50qjkmispsnqn5fdla20gdii32q6j6ul', '127.0.0.1', '1519895974', '__ci_last_regenerate|i:1519895974;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6r5a2rsps0u3vkveih451iojobeh1pd0', '127.0.0.1', '1519896105', '__ci_last_regenerate|i:1519896105;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jphdghvud6ks3hcv7li2c53d2rp2ulu9', '127.0.0.1', '1519896110', '__ci_last_regenerate|i:1519896110;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4cf5n3u9fl8is26tb1vdkaoco0a0m3ek', '127.0.0.1', '1519896114', '__ci_last_regenerate|i:1519896114;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4g1sa50g4obg12nu1q06qlm5m01nbs1', '127.0.0.1', '1519896128', '__ci_last_regenerate|i:1519896128;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pt238numbmctlulg9i9mbsejfi6ba145', '127.0.0.1', '1519896608', '__ci_last_regenerate|i:1519896608;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h5tbrhgj9jnes3jvuv4fkps31qn62ego', '127.0.0.1', '1519896992', '__ci_last_regenerate|i:1519896992;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ma5sul6ig8g43c9qe3k6n82nfpsi3e73', '127.0.0.1', '1519897393', '__ci_last_regenerate|i:1519897393;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nc9rlv7ja5bo1pk1lvg2cbv15doomguj', '127.0.0.1', '1519897263', '__ci_last_regenerate|i:1519897262;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhuhoi7o5ajd4ngvd82b526a69n0u70i', '127.0.0.1', '1519897282', '__ci_last_regenerate|i:1519897282;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bnn931ks0v82lpgvcnt5nbaor22mju4f', '127.0.0.1', '1519897290', '__ci_last_regenerate|i:1519897290;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i0at8m18pljucemonmj0o83rj1cek1fd', '127.0.0.1', '1519897294', '__ci_last_regenerate|i:1519897293;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('chd7rolqoghbb08kvko9bpkrb2ierfa8', '127.0.0.1', '1519897314', '__ci_last_regenerate|i:1519897314;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t2hvoebv33l43k4elldgq21m92876gbl', '127.0.0.1', '1519897320', '__ci_last_regenerate|i:1519897319;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('704esshi6aot14k3705dg26pn33tcrnc', '127.0.0.1', '1519897329', '__ci_last_regenerate|i:1519897328;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t7ugksg5a8gr4s81dt15sa5f8dke993n', '127.0.0.1', '1519897337', '__ci_last_regenerate|i:1519897336;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mpevddipigvvp3f4usteljrq32vgh6f4', '127.0.0.1', '1519897765', '__ci_last_regenerate|i:1519897765;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n9ffjesk1lvo7iibacolskishr1d37nc', '127.0.0.1', '1519897410', '__ci_last_regenerate|i:1519897409;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n6ishqdg0j4o807nhhgaf5sfd3r2cbcg', '127.0.0.1', '1519897415', '__ci_last_regenerate|i:1519897414;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ekvnh8seego0n0fq1nnsmn9iuf2kgd1', '127.0.0.1', '1519897424', '__ci_last_regenerate|i:1519897424;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('reg989tstcttnf4stskrsquahcgbc1f5', '127.0.0.1', '1519897429', '__ci_last_regenerate|i:1519897428;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s8me205f7a8lckhbf2ntkbbrc8807n85', '127.0.0.1', '1519897434', '__ci_last_regenerate|i:1519897434;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cj2qcijte7edt28fbr6b5p6a73put990', '127.0.0.1', '1519897441', '__ci_last_regenerate|i:1519897440;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aqkpka4l20h4ub13v2bm346dn5mu5ra9', '127.0.0.1', '1519897446', '__ci_last_regenerate|i:1519897446;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpn1vk5tnup4jo7d902soeca1aho1gfi', '127.0.0.1', '1519897460', '__ci_last_regenerate|i:1519897460;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ksagmolim1ai6nfoejc915kvptklp74u', '127.0.0.1', '1519897639', '__ci_last_regenerate|i:1519897638;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s6in573hh9fdqp82vdmlpesbrtv0vsps', '127.0.0.1', '1519897662', '__ci_last_regenerate|i:1519897662;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('samo5fahj3eoai9oci8q0jofqamaeqos', '127.0.0.1', '1519897759', '__ci_last_regenerate|i:1519897758;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6hjt0rjie9anbdqbbro0i6mf0pk00nc5', '127.0.0.1', '1519898764', '__ci_last_regenerate|i:1519898764;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c6nl07ecr5hv72raii2i7iiod81hm19u', '127.0.0.1', '1519897780', '__ci_last_regenerate|i:1519897779;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dddgnqvbu199q7n047bgf3nba5bs2mcn', '127.0.0.1', '1519897988', '__ci_last_regenerate|i:1519897988;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('566h5e81h4hk709e3mofrh9gnf9c1pnu', '127.0.0.1', '1519898009', '__ci_last_regenerate|i:1519898009;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jb47sgmpnnto8aj31pg9lomp9ckgjtcr', '127.0.0.1', '1519898012', '__ci_last_regenerate|i:1519898012;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vo21r287seful1hu28tjsp5h0df7i4td', '127.0.0.1', '1519898074', '__ci_last_regenerate|i:1519898074;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17q1kh7s071djjro268rebsg9ntv338b', '127.0.0.1', '1519898472', '__ci_last_regenerate|i:1519898471;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('953693ts743163ddqhhkspc1bhb3qdgs', '127.0.0.1', '1519898517', '__ci_last_regenerate|i:1519898516;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf8vppm1sks5ft8rkgb504guiknanoql', '127.0.0.1', '1519898617', '__ci_last_regenerate|i:1519898617;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3qee92hf58eg7ij28up57bm4q2mt06c3', '127.0.0.1', '1519898646', '__ci_last_regenerate|i:1519898646;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r3pmhs0m0ib1tteps4u5j4gnimu69te9', '127.0.0.1', '1519898745', '__ci_last_regenerate|i:1519898744;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jesc08enjomkrmkulgeknbt337b4uod1', '127.0.0.1', '1519898757', '__ci_last_regenerate|i:1519898756;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('th6oplpdr6k0alqjpdt1cki0unghq82g', '127.0.0.1', '1519899060', '__ci_last_regenerate|i:1519898764;client_user_id|s:1:\"1\";contact_user_id|s:1:\"1\";client_logged_in|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('alooim1unipe83h5qevr5t3gfpevlht7', '127.0.0.1', '1519898781', '__ci_last_regenerate|i:1519898781;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m65btie1dlkuhheu5ptiu8hv1ur905cq', '127.0.0.1', '1519898798', '__ci_last_regenerate|i:1519898798;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9kro2e1v3cifmg5m1fjemi88qru9qad9', '127.0.0.1', '1519898828', '__ci_last_regenerate|i:1519898827;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('llak4bu30lkkfsdn42k9pobq5scd2353', '127.0.0.1', '1519898854', '__ci_last_regenerate|i:1519898854;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1uc9raelp1i42i4s1ln29koo605j3tg', '127.0.0.1', '1519898865', '__ci_last_regenerate|i:1519898865;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n5cttkkk9l9ikl723jb7mkd9h25995l6', '127.0.0.1', '1519898871', '__ci_last_regenerate|i:1519898871;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('chcegtjlkmgntjehg4420n8uvtrvlurd', '127.0.0.1', '1519898881', '__ci_last_regenerate|i:1519898880;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('te1tskpc5kh1vqahnls4pqbb91eqi3kg', '127.0.0.1', '1519898903', '__ci_last_regenerate|i:1519898902;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('028i21r5pgku798f2tonadvpph2tgphg', '127.0.0.1', '1519898907', '__ci_last_regenerate|i:1519898907;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jva92e6ircahjnup1r4tp3o97n1n8da9', '127.0.0.1', '1519898911', '__ci_last_regenerate|i:1519898910;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dooroshkn52eodu6evcn14slkcnr5nmo', '127.0.0.1', '1519898915', '__ci_last_regenerate|i:1519898915;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('onau8sdts3iqv91ek8v3ndc6is7jshq2', '127.0.0.1', '1519898930', '__ci_last_regenerate|i:1519898929;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ksfnp9fngiee21nt5c80ao85j4rutos5', '127.0.0.1', '1519898935', '__ci_last_regenerate|i:1519898934;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99kplg8cunm9s3jbuctvurkjnmap7d6v', '127.0.0.1', '1519898942', '__ci_last_regenerate|i:1519898942;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cgn8u1e82jlvu7au0djdigj9o39den1j', '127.0.0.1', '1519898947', '__ci_last_regenerate|i:1519898947;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('92gl695ae6n5c5mlmpgdpbihhm0ntp3l', '127.0.0.1', '1519898951', '__ci_last_regenerate|i:1519898950;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6kh4bstrsvobjsbugq1stvfbjrli3mo', '127.0.0.1', '1519898955', '__ci_last_regenerate|i:1519898955;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kiju7b3up77hhqqhhupqgkgufoeht6pl', '127.0.0.1', '1519898964', '__ci_last_regenerate|i:1519898963;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tfjt7umhhpjm9cq4bjd3nb8i7p50451r', '127.0.0.1', '1519899060', '__ci_last_regenerate|i:1519899060;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd91im8vau4g295pa2tuh34et6ieebpb', '127.0.0.1', '1519899302', '__ci_last_regenerate|i:1519899301;staff_user_id|s:1:\"1\";staff_logged_in|b:1;');


#
# TABLE STRUCTURE FOR: tblsmalltalkreferences
#

DROP TABLE IF EXISTS `tblsmalltalkreferences`;

CREATE TABLE `tblsmalltalkreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smalltalkid` int(11) NOT NULL,
  `question` text COLLATE utf8_unicode_ci,
  `answer` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`,`smalltalkid`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('114', '3', ' who are you?', 'i am echelon.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('115', '3', ' how old are you?', 'i am 2 years old.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('116', '3', 'who is your creator?', 'my creator is ahmet goudenoglu.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('117', '3', 'can you love?', 'yes. i can. i have feelings too.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('118', '3', 'who do you love', 'i love my vreator');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('119', '3', 'do you love', 'yes i do');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('120', '3', 'can you get smarter?', 'ofcourse i can. my creator design me to learn.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('121', '3', 'how do you learn?', 'i can learn from users. as much as i talk with them i learn new things.');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('122', '5', 'ha ha ha!', 'what is funny?');
INSERT INTO `tblsmalltalkreferences` (`id`, `smalltalkid`, `question`, `answer`) VALUES ('123', '5', 'wow!', 'ha. i guess you are amazed.');


#
# TABLE STRUCTURE FOR: tblsmalltalks
#

DROP TABLE IF EXISTS `tblsmalltalks`;

CREATE TABLE `tblsmalltalks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `small_talk_name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_system` int(1) DEFAULT '0',
  `merge` int(1) DEFAULT '0',
  `is_default` int(1) DEFAULT '0',
  `is_public` int(1) DEFAULT '0',
  PRIMARY KEY (`id`,`agentid`,`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('3', '1', '1', ' About agent', 'about.agent', '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('4', '1', '1', ' Courtesy', NULL, '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('5', '1', '1', ' Emotions', 'bot.emotions', '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('6', '1', '1', ' Hello/Goodbye', NULL, '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('7', '1', '1', 'About user', NULL, '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('8', '1', '1', 'Confirmation', NULL, '0', '0', '0', '0');
INSERT INTO `tblsmalltalks` (`id`, `agentid`, `userid`, `small_talk_name`, `action`, `is_system`, `merge`, `is_default`, `is_public`) VALUES ('9', '1', '1', 'Other questions and phrases', NULL, '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` mediumtext,
  `linkedin` mediumtext,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(300) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(300) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  `email_signature` text,
  PRIMARY KEY (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `email_signature`) VALUES ('1', 'ahmet.gudenoglu@gmail.com', '', '', NULL, NULL, NULL, NULL, '$2a$08$IgCoaD3DdYJOUcpxw64Ss.Ggb1naYs0d6O7V8itZHTBBDgBeTI946', '2018-02-25 12:24:53', NULL, '127.0.0.1', '2018-03-01 10:15:06', NULL, NULL, NULL, '1', NULL, '1', NULL, NULL, NULL, '0', '0.00', NULL);


#
# TABLE STRUCTURE FOR: tblstaffdepartments
#

DROP TABLE IF EXISTS `tblstaffdepartments`;

CREATE TABLE `tblstaffdepartments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaffpermissions
#

DROP TABLE IF EXISTS `tblstaffpermissions`;

CREATE TABLE `tblstaffpermissions` (
  `staffpermid` int(11) NOT NULL AUTO_INCREMENT,
  `permissionid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `staffid` int(11) NOT NULL,
  PRIMARY KEY (`staffpermid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstafftaskassignees
#

DROP TABLE IF EXISTS `tblstafftaskassignees`;

CREATE TABLE `tblstafftaskassignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstafftaskcomments
#

DROP TABLE IF EXISTS `tblstafftaskcomments`;

CREATE TABLE `tblstafftaskcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstafftasks
#

DROP TABLE IF EXISTS `tblstafftasks`;

CREATE TABLE `tblstafftasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext,
  `description` text,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_ends_on` date DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `billable` tinyint(1) NOT NULL DEFAULT '0',
  `billed` tinyint(1) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  `milestone` int(11) DEFAULT '0',
  `kanban_order` int(11) NOT NULL DEFAULT '0',
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `deadline_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstafftasksfollowers
#

DROP TABLE IF EXISTS `tblstafftasksfollowers`;

CREATE TABLE `tblstafftasksfollowers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveyresultsets
#

DROP TABLE IF EXISTS `tblsurveyresultsets`;

CREATE TABLE `tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveys
#

DROP TABLE IF EXISTS `tblsurveys`;

CREATE TABLE `tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT '0',
  `onlyforloggedin` int(11) DEFAULT '0',
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysemailsendcron
#

DROP TABLE IF EXISTS `tblsurveysemailsendcron`;

CREATE TABLE `tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysendlog
#

DROP TABLE IF EXISTS `tblsurveysendlog`;

CREATE TABLE `tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT '0',
  `send_to_mail_lists` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags_in
#

DROP TABLE IF EXISTS `tbltags_in`;

CREATE TABLE `tbltags_in` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT '0',
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskchecklists
#

DROP TABLE IF EXISTS `tbltaskchecklists`;

CREATE TABLE `tbltaskchecklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `finished` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT '0',
  `list_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(11,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketattachments
#

DROP TABLE IF EXISTS `tblticketattachments`;

CREATE TABLE `tblticketattachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` mediumtext NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketpipelog
#

DROP TABLE IF EXISTS `tblticketpipelog`;

CREATE TABLE `tblticketpipelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(500) NOT NULL,
  `name` varchar(200) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `message` mediumtext NOT NULL,
  `email` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketreplies
#

DROP TABLE IF EXISTS `tblticketreplies`;

CREATE TABLE `tblticketreplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `name` text,
  `email` text,
  `date` datetime NOT NULL,
  `message` text,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `ip` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `email` text,
  `name` text,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message` text,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT '0',
  `adminread` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(40) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketsspamcontrol
#

DROP TABLE IF EXISTS `tblticketsspamcontrol`;

CREATE TABLE `tblticketsspamcontrol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticketstatus
#

DROP TABLE IF EXISTS `tblticketstatus`;

CREATE TABLE `tblticketstatus` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT '0',
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('3', 'Answered', '1', '#0000ff', '3');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('4', 'On Hold', '1', '#c0c0c0', '4');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('2', 'In progress', '1', '#84c529', '2');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('5', 'Closed', '1', '#03a9f4', '5');
INSERT INTO `tblticketstatus` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES ('1', 'Open', '1', '#ff2d42', '1');


#
# TABLE STRUCTURE FOR: tbltodoitems
#

DROP TABLE IF EXISTS `tbltodoitems`;

CREATE TABLE `tbltodoitems` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluserautologin
#

DROP TABLE IF EXISTS `tbluserautologin`;

CREATE TABLE `tbluserautologin` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblviewstracking
#

DROP TABLE IF EXISTS `tblviewstracking`;

CREATE TABLE `tblviewstracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblwebtolead
#

DROP TABLE IF EXISTS `tblwebtolead`;

CREATE TABLE `tblwebtolead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `responsible` int(11) NOT NULL DEFAULT '0',
  `name` varchar(400) NOT NULL,
  `form_data` mediumtext,
  `recaptcha` int(11) NOT NULL DEFAULT '0',
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT '1',
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

